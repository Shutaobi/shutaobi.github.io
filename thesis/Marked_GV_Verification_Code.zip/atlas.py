#!/usr/bin/env python3
"""Audit the 27 low-rank GV rows against all compatible exceptional Cartan images.

    python3 atlas.py --paper Marked_GV_Realisation_Clean.tex [--row 3f]

Requires Python 3.9+, SymPy and z3-solver. The supplied TeX provides the three
Appendix A support tables. The audit generates root systems, integral matches,
initial patterns, tail constraints and sign-pair groups.
"""

import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import cache
from itertools import chain, combinations, groupby, permutations, product
from math import lcm
from pathlib import Path
import platform
import re
import sys
from time import monotonic

import sympy as sp
from sympy.matrices.normalforms import hermite_normal_form
import z3

from cartan import cartan_image, projected_support, require, root_system, sign_pair
from rows import ROW_NAMES, add, bc_axes, double, read_rows


def based_type(support):
    """Canonicalize under coordinate permutations, the positive chamber marking.

    Sort axes by two permutation invariants, then minimize the entire vector
    set over all orders that tie. Equality of the invariants alone is unused.
    """
    r = len(support[0])
    weights = [sum(v) for v in support]
    keys = [(sum(v[j] for v in support), sum(w*v[j] for w, v in zip(weights, support)))
            for j in range(r)]
    ordered = sorted(range(r), key=keys.__getitem__)
    ties = [tuple(group) for _, group in groupby(ordered, key=keys.__getitem__)]
    orders = (tuple(chain.from_iterable(blocks))
              for blocks in product(*(permutations(group) for group in ties)))
    return min(tuple(sorted(tuple(v[j] for j in order) for v in support)) for order in orders)


@cache
def metric(support):
    """Second moment, represented by its determinant and integral adjugate."""
    a = sp.Matrix(support)
    moment = a.T * a
    det = int(moment.det())
    adj = (det * moment.inv()).tolist()
    return det, tuple(tuple(map(int, row)) for row in adj)


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def isometries(source, target):
    """Enumerate all integral signed-set maps, up to simultaneous negation.

    The standard basis lies in the source sign-pairs. Its image determines the
    whole map. If U maps the signed set, then M_target = U M_source U^T.
    The adjugate pairings prune the basis choices; the final GL(Z) and full
    signed-set tests decide the match.
    """
    r = len(source[0])
    if len(target[0]) != r or len(target) != len(source):
        return
    require(all(tuple(int(i == j) for j in range(r)) in source for i in range(r)),
            "The matching source must contain its standard basis")
    det_s, form_s = metric(source)
    det_t, form_t = metric(target)
    if det_s != det_t:
        return
    target_set = set(target)
    signed = target + tuple(tuple(-x for x in v) for v in target)
    dual = {v: tuple(dot(row, v) for row in form_t) for v in signed}
    pools = [[v for v in (signed if i else target) if dot(v, dual[v]) == form_s[i][i]]
             for i in range(r)]

    def extend_basis(columns):
        i = len(columns)
        if i < r:
            for v in pools[i]:
                if all(dot(v, dual[w]) == form_s[i][j] for j, w in enumerate(columns)):
                    yield from extend_basis(columns + (v,))
            return
        if abs(sp.Matrix(columns).det()) != 1:
            return
        rows = tuple(zip(*columns))
        image = tuple(sign_pair(tuple(dot(row, v) for row in rows)) for v in source)
        if set(image) == target_set:
            yield image

    yield from extend_basis(())


def lattice_support(labels):
    """Express the vectors in a basis of their generated lattice (also for weights)."""
    a = sp.Matrix.hstack(*labels)
    integral = a * lcm(*(int(x.q) for x in a))
    basis = hermite_normal_form(integral.to_DM().convert_to(sp.ZZ).to_Matrix())
    coords = basis.gauss_jordan_solve(integral)[0]
    require(all(x.is_Integer for x in coords), "Nonintegral model coordinates")
    return tuple(sorted({sign_pair(map(int, coords[:, j])) for j in range(coords.cols)}))


def other_low_rank_supports(r):
    """The low-rank support shapes in the first alternative of Theorem 2.1.

    Build directly from the classical frames (§3) and the ordinary, folded
    and rank-two configurations (§6). Only signed support is used here.
    """
    unit = [sp.eye(r)[:, j] for j in range(r)]
    pairs = [a + s*b for a, b in combinations(unit, 2) for s in (-1, 1)]
    for k in range(r + 1):  # Up to permuting axes, k specifies every doubling set.
        doubles = [2*a for a in unit[:k]]
        if r != 2 or k != 0:    # Pure D2 is reducible.
            yield lattice_support(pairs + doubles)
        yield lattice_support(pairs + unit + doubles)

    def standard_weights(d):
        return [sp.eye(d)[:, j] - sp.ones(d, 1)/d for j in range(d)]

    weights = standard_weights(r + 1)
    a_roots = [a - b for a, b in combinations(weights, 2)]
    yield lattice_support(a_roots)
    if r == 2:
        a, b = unit
        short = [b, a+b, a+2*b]
        g2 = short + [a, a+3*b, 2*a+3*b]
        yield lattice_support(g2)
        yield lattice_support(g2 + [2*s for s in short])
        # The five-label family is already a terminal frame with one doubling.
        yield lattice_support([a, b, 2*a, 2*b, a+b, a-b, a+2*b, a-2*b])
        yield lattice_support([a, 2*a, 3*a, b, 2*b, b+a, b-a, b+2*a, b-2*a])
    else:
        spin = [sp.Matrix(signs)/2 for signs in product((-1, 1), repeat=r)]
        yield lattice_support(unit + pairs + spin)  # Spin B3, or full F4.
        if r == 3:
            yield lattice_support(unit + pairs + [sp.ones(3, 1)])  # Diagonal B3.
        else:
            # A4 with omega_1,omega_2 and their negatives.
            yield lattice_support(a_roots + weights + [a+b for a, b in combinations(weights, 2)])
            # Two A2 factors with the signed orbit of (omega_1,omega_1).
            w = standard_weights(3)
            zero = sp.zeros(3, 1)
            roots = [a-b for a, b in combinations(w, 2)]
            labels = [a.col_join(zero) for a in roots] + [zero.col_join(a) for a in roots]
            yield lattice_support(labels + [a.col_join(b) for a, b in product(w, repeat=2)])


@dataclass
class Match:
    ambient: int
    visible: tuple
    image: tuple

    def name(self):
        # Vertex numbers in the paper start at 1.
        nodes = ",".join(str(j+1) for j in self.visible)
        return f"E{self.ambient}/J={{{nodes}}}"


def inventory(rows):
    candidates = defaultdict(list)
    for row in rows.values():
        candidates[int(row.name[0]), len(row.support)].append(row)
    other_shapes = defaultdict(set)
    for r in (2, 3, 4):
        for shape in other_low_rank_supports(r):
            other_shapes[r, len(shape)].add(shape)
    matches = defaultdict(list)
    marked = defaultdict(set)
    all_types = defaultdict(set)
    owners = {}
    count = Counter()
    for n in (6, 7, 8):
        roots = root_system(n)[0]
        for r in range(1, n + 1):
            for visible in combinations(range(n), r):
                count[n] += 1
                support = projected_support(roots, visible)
                based = based_type(support)
                all_types[r].add(based)
                hits = []
                for row in candidates[r, len(support)]:
                    image = next(isometries(row.support, support), None)
                    if image is not None:
                        hits.append(row.name)
                        matches[row.name].append(Match(n, visible, image))
                        marked[row.name].add(based)
                require(len(hits) <= 1, f"E{n}, {visible}: ambiguous rows {hits}")
                owner = tuple(hits)
                require(owners.setdefault(based, owner) == owner,
                        "Repeated positive type has inconsistent row membership")
                if 2 <= r <= 4:
                    other = any(next(isometries(support, shape), None) is not None
                                for shape in other_shapes[r, len(support)])
                    require(bool(hits) != other,
                            f"E{n}, {visible}: first alternative and row matches {other}, {hits}")

    require(count == {6: 63, 7: 127, 8: 255}, f"Parabolic census {count}")
    by_rank = [len(all_types[r]) for r in range(1, 9)]
    require(by_rank == [6, 38, 94, 113, 81, 36, 9, 1], f"Based census {by_rank}")
    print(f"The {sum(count.values())} exceptional choices give {sum(by_rank)} positive "
          "marked types across ranks 1–8.")
    for r, expected in [(2, (8, 25, 35)), (3, (11, 83, 86)), (4, (8, 103, 107))]:
        names = [k for k in rows if int(k[0]) == r and matches[k]]
        found = len(names), sum(len(marked[k]) for k in names), sum(len(matches[k]) for k in names)
        require(found == expected, f"Rank {r} row/marked/presentation census: {found}")
        print(f"  Rank {r} has {found[0]} rows, {found[1]} marked types and "
              f"{found[2]} presentations.")
    remaining = sum(not owner and 2 <= len(based[0]) <= 4 for based, owner in owners.items())
    require(remaining == 34, f"First-alternative low-rank marked types: {remaining}")
    covered = sum(bool(owner) for owner in owners.values())
    print(f"Appendix A covers {covered} marked types in {sum(map(len, matches.values()))} "
          f"presentations. Of the {len(owners)-covered} other types, all {remaining} in "
          "ranks 2–4 match first-alternative supports.", flush=True)
    return matches, marked


def symmetry_group(support):
    """Generate the full group on sign-pairs from exhaustively enumerated maps."""
    indices = {v: i for i, v in enumerate(support)}
    group = {tuple(indices[v] for v in image) for image in isometries(support, support)}
    identity = tuple(range(len(support)))
    subgroup = {identity}
    gens = []
    for perm in sorted(group):
        if perm in subgroup:
            continue
        gens.append(perm)
        pending = list(subgroup)
        while pending:
            a = pending.pop()
            for b in gens:
                c = tuple(a[i] for i in b)
                if c not in subgroup:
                    subgroup.add(c)
                    pending.append(c)
    require(subgroup == group, "Generator closure differs from the enumerated sign-pair group")
    return group, gens


class Queries:
    def __init__(self, variables, timeout_ms, smt_dir=None):
        self.smt_dir = smt_dir
        self.variables = variables
        self.timeout_ms = timeout_ms
        self.positive = [x > 0 for x in variables.values()]
        self.count = Counter()

    def check(self, condition, expected, context):
        solver = z3.Solver()
        if self.timeout_ms:
            solver.set(timeout=self.timeout_ms)
        solver.add(*self.positive, z3.simplify(condition))
        if self.smt_dir is not None:
            self.smt_dir.mkdir(parents=True, exist_ok=True)
            number = sum(self.count.values()) + 1
            target = self.smt_dir / f"{number:04d}-{expected}.smt2"
            contents = f"; {context}\n; Expected result: {expected}\n" + solver.to_smt2()
            target.write_text(contents, encoding="utf-8")
        result = solver.check()
        if result == z3.unknown:
            raise ValueError(f"{context}: solver unknown ({solver.reason_unknown()})")
        if result != expected:
            detail = ""
            if result == z3.sat:
                model = solver.model()
                detail = "  " + " ".join(
                    f"{''.join(map(str, t))}={model.eval(v, model_completion=True)}"
                    for t, v in self.variables.items())
            raise ValueError(f"{context}: expected {expected}, got {result}.{detail}")
        self.count[str(result)] += 1


def separating_tuple(row):
    """Section 4.5: 5 on primitive axes, 1 on doubles, 3 on pairs, 1 on triples."""
    axes = bc_axes(row.variable)
    values = {a: 5 for a in axes}
    values.update({double(a): 1 for a in axes})
    for a, b in combinations(axes, 2):
        for sign in (-1, 1):
            values[sign_pair(add(a, b, sign))] = 3
    a, b, c = axes
    for s, t in product((-1, 1), repeat=2):
        values[sign_pair(add(add(a, b, s), c, t))] = 1
    require(set(values) == set(row.support), "Separator does not label the whole 3f support")
    return values


def audit_row(row, matches, marked, timeout_ms, detail, smt_dir=None):
    support = row.support
    xs = [z3.Int("n_" + "_".join(map(str, t))) for t in support]
    numbers = dict(zip(support, xs))
    query = Queries(numbers, timeout_ms, smt_dir)
    printed = row.predicate(numbers)
    group, generators = symmetry_group(support)
    for perm in group:
        require(all(row.fixed.get(t) == row.fixed.get(support[j]) for t, j in zip(support, perm)),
                f"{row.name}: an automorphism changed a fixed-value class")
    for i, perm in enumerate(generators, 1):
        moved = z3.substitute(printed, *[(v, xs[j]) for v, j in zip(xs, perm)])
        query.check(z3.Xor(printed, moved), z3.unsat, f"{row.name} marking generator {i}")

    if row.name == "3f":
        types = Counter(p.ambient for p in matches)
        require(types == {7: 2, 8: 2}, f"3f contenders: {types}")
        values = separating_tuple(row)
        require(all(all(values[support[i]] == values[support[j]] for i, j in enumerate(perm))
                    for perm in group), "3f separator changed with the marking")
        at_tuple = z3.And([x == values[t] for t, x in numbers.items()])
        query.check(z3.And(at_tuple, printed), z3.sat, "3f separator in the printed row")
        print(f"  The row 3f separator has printed variable entries "
              f"{tuple(values[t] for t in row.variable)}. All four fixed entries equal 1.")

    images = []
    prefix_count = 0
    realizers = []
    realized_types = set()
    for match in matches:
        context = f"{row.name} {match.name()}"
        target_numbers = dict(zip(match.image, xs))
        branches = cartan_image(match.ambient, match.visible, target_numbers)
        prefix_count += len(branches)
        image = z3.Or(branches)
        images.append(image)
        for i, branch in enumerate(branches, 1):
            query.check(z3.And(branch, z3.Not(printed)), z3.unsat,
                        f"{context}, prefix {i}: Cartan image implies row")
        exact = row.name != "3f" or match.ambient == 7
        if exact:
            query.check(z3.And(printed, z3.Not(image)), z3.unsat,
                        f"{context}: row implies Cartan image")
            realizers.append(match.name())
            realized_types.add(based_type(match.image))
        if row.name == "3f":
            query.check(z3.And(at_tuple, image), z3.sat if exact else z3.unsat,
                        f"{context}: separating tuple")
            outcome = "accepts it (full row)" if exact else "excludes it (proper subset)"
            print(f"    {match.name()} {outcome}.", flush=True)
        elif detail:
            print(f"    {match.name()} realizes the full row ({len(branches)} prefix orbits).")

    require(realizers, f"{row.name}: no individual presentation proved to realize the row")
    require(realized_types == marked, f"{row.name}: a based chamber type lacks a full-row realizer")
    union = z3.Or(images)
    query.check(z3.And(printed, z3.Not(union)), z3.unsat, f"{row.name}: coverage by union")
    query.check(z3.And(printed, union), z3.sat, f"{row.name}: nonempty realization")
    print(f"{row.name:>3} {len(marked):>7} {len(matches):>14} {prefix_count:>9} "
          f"{len(group):>14} {len(generators):>12} {len(realizers):>9}   {realizers[0]}",
          flush=True)
    return Counter(rows=1, marked=len(marked), presentations=len(matches), prefixes=prefix_count,
                   symmetries=len(group), generators=len(generators), exact=len(realizers),
                   unsat=query.count["unsat"], sat=query.count["sat"])


def check_manuscript_displays(path, rows, totals_by_rank, selected_row):
    """Compare computed results with the two labelled displays in the integrated edition."""
    tex = path.read_text(encoding="utf-8")
    example = r"\label{eq:row-three-f-columns}"
    census = r"\label{eq:rank-comparison-counts}"
    if example not in tex and census not in tex:
        return  # Earlier editions supply the Appendix A input tables alone.
    require(tex.count(example) == tex.count(census) == 1, "Missing or duplicate verification display")

    if selected_row in (None, "3f"):
        equation = tex.split(example, 1)[1].split(r"\end{equation}", 1)[0]
        match = re.fullmatch(r"\s*\(\s*([\d,\s]+)\s*\)\s*\.?\s*", equation)
        require(match is not None, "Unreadable row 3f tuple in Section 4.5")
        row = rows["3f"]
        values = separating_tuple(row)
        printed = tuple(int(x.strip()) for x in match.group(1).split(","))
        expected = tuple(values[v] for v in row.variable)
        require(printed == expected, f"Section 4.5 prints {printed}; expected {expected}")
        print("Section 4.5: the separating tuple agrees in Appendix A column order.")

    if selected_row is not None:
        return
    table = tex.split(census, 1)[1].split(r"\end{array}", 1)[0]
    printed_counts = {}
    for line in table.splitlines():
        if not re.match(r"^\s*(?:\d+\s*)?&\s*\d", line):
            continue
        cells = line.split(r"\\", 1)[0].replace(r"\,", "").strip().rstrip(".").split("&")
        rank, *entries = (s.strip() for s in cells)
        rank = int(rank) if rank else 0
        require(rank not in printed_counts and len(entries) == 4, "Malformed rank-count table")
        printed_counts[rank] = tuple(map(int, entries))
    fields = ("rows", "marked", "presentations", "prefixes")
    expected = {rank: tuple(counts[k] for k in fields) for rank, counts in totals_by_rank.items()}
    expected[0] = tuple(map(sum, zip(*expected.values())))
    require(printed_counts == expected, f"Appendix B.3.1 prints {printed_counts}; expected {expected}")
    print("Appendix B.3.1: all three rank counts and the total agree.")


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--paper", default=None, type=Path, metavar="PATH",
                        help="read Appendix A from this TeX source and check the integrated manuscript displays")
    parser.add_argument("--row", choices=ROW_NAMES,
                        help="restrict the arithmetic to one row and list its presentations")
    parser.add_argument("--timeout-ms", type=int, default=0, metavar="MS",
                        help="optional per-query solver limit (default: unlimited)")
    parser.add_argument("--smt-dir", type=Path, help="write the exact SMT-LIB queries, grouped by row")
    args = parser.parse_args()
    require(args.timeout_ms >= 0, "Timeout must be nonnegative")
    started = monotonic()
    print(f"Python {platform.python_version()}, SymPy {sp.__version__}, Z3 {z3.get_version_string()}",
          flush=True)
    rows = read_rows(args.paper)
    matches, marked = inventory(rows)
    total = Counter()
    print("Row  Marked  Presentations  Prefixes   Permutations   Generators  Full row   "
          "One full-row presentation (one-based J)")
    totals_by_rank = defaultdict(Counter)
    for name in ([args.row] if args.row else ROW_NAMES):
        counts = audit_row(rows[name], matches[name], marked[name], args.timeout_ms,
                           detail=bool(args.row),
                           smt_dir=(args.smt_dir / name if args.smt_dir else None))
        total.update(counts)
        totals_by_rank[int(name[0])].update(counts)
    if args.paper is not None:
        check_manuscript_displays(args.paper, rows, totals_by_rank, args.row)
    if not args.row:
        fields = ("rows", "marked", "presentations", "prefixes", "symmetries", "exact")
        require(tuple(total[k] for k in fields) == (27, 211, 228, 1158, 734, 226),
                f"Final atlas totals differ: {dict(total)}")
    print(f"PASS  {total['rows']} rows, {total['marked']} marked types, "
          f"{total['presentations']} presentations, {total['prefixes']} smooth prefix orbits, "
          f"{total['symmetries']} sign-pair permutations ({total['generators']} generators).")
    print(f"  {total['exact']} presentations realize their entire row. "
          f"{total['unsat']} counterexample/exclusion queries were unsatisfiable. "
          f"{total['sat']} realization checks were satisfiable. Elapsed {monotonic()-started:.1f}s.")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        sys.exit(f"FAIL: {error}")
