#!/usr/bin/env python3
"""Regenerate the exceptional support inventory and labelled root-fibre calculations.

Run python3 finite.py to check Section 6 and Appendix B. Add --paper PATH to
read the manuscript tables, or --show E7/125 to print one marking.
Nodes in command-line arguments and printed endpoints start at 1.
"""
import argparse
from collections import Counter, defaultdict, deque
from itertools import combinations, permutations, product
from math import comb, gcd, prod

from sympy import Matrix, Poly, Symbol, cyclotomic_poly, diag, eye, zeros
from sympy.matrices.normalforms import hermite_normal_form

from root_data import (
    ORDINARY,
    Coxeter,
    Exceptional,
    Model,
    Presentation,
    add,
    based_form,
    based_classical,
    diagram,
    dot,
    moment,
    mv,
    pair,
    project,
    primitive,
    rows,
    scale,
    simple_parts,
    signature,
    signed_models,
    unit,
)


from rows import read_rows


def rank_counts(items):
    counts = Counter(items)
    return tuple(counts[r] for r in range(1, 9))


def moment_lengths(model):
    """Support symmetries must preserve the geometric label classes used in the rules."""
    source = tuple(model.tags)
    _, H = moment(source)
    by_length = {}
    for v, tag in model.tags.items():
        norm = dot(v, mv(H, v))
        assert by_length.setdefault(norm, tag) == tag, (model.name, tag)
    # Relative squared lengths from the six rows of section 6.2.
    ratios = {
        'spin3': {'spin': 3, 'short': 4, 'long': 8},
        'spin5': {'short': 4, 'spin': 5, 'long': 8},
        'spin6': {'short': 2, 'spin': 3, 'long': 4},
        'diagonal': {'short': 7, 'plus': 12, 'diagonal': 15, 'minus': 16},
        'B4+line': {'short': 20, 'spin': 31, 'long': 40, 'line': 44},
        'F4+line': {'line': 15, 'short': 29, 'mixed': 44, 'long': 58, 'double': 60},
    }
    if model.name in ratios:
        lengths = ratios[model.name]
        assert set(lengths) == set(by_length.values())
        base = min(by_length)
        assert all(x * lengths[by_length[base]] == base * lengths[t] for x, t in by_length.items())


def inventory(paper=None):
    systems = {n: Exceptional(n) for n in (6, 7, 8)}
    all_p = [
        Presentation(E, J) for n, E in systems.items() for r in range(1, n + 1) for J in combinations(range(n), r)
    ]
    models = list(signed_models(systems))
    for name, row in read_rows(paper).items():
        models.append(Model(name, [(v, 'atlas') for v in row.support], atlas=True))
    index = defaultdict(list)
    for model in models:
        moment_lengths(model)
        index[signature(model.B)].append(model)
    types = {}
    families = defaultdict(list)
    for p in all_p:
        matches = []
        for model in index[signature(p.B)]:
            marking = model.marking(p.B)
            if marking is not None:
                matches.append((model, marking))
        assert len(matches) == 1, (p.name, [m.name for m, _ in matches])
        p.model, p.marking = matches[0]
        p.family = p.model.name
        p.tags = {b: p.model.tags[pair(v)] for b, v in p.marking.items()}
        p.atlas = p.model.atlas
        p.key, p.basis_order = based_form(p.B)
        assert types.setdefault(p.key, p.family) == p.family
        families[p.family].append(p)

    assert len(all_p) == 445 and len(types) == 378
    assert len(families) == len(models)
    summaries = set()
    for B in types:
        height = tuple(map(sum, B))
        sums = tuple(sorted((sum(col), dot(height, col)) for col in zip(*B)))
        summaries.add((len(B), sums))
    assert len(summaries) == len(types)
    first = {p.key for p in all_p if not p.atlas}
    second = {p.key for p in all_p if p.atlas}
    assert first.isdisjoint(second) and first | second == set(types)
    assert rank_counts(len(B[0]) for B in types) == (6, 38, 94, 113, 81, 36, 9, 1)
    assert rank_counts(len(B[0]) for B in first) == (6, 13, 11, 10, 81, 36, 9, 1)
    assert rank_counts(len(B[0]) for B in second) == (0, 25, 83, 103, 0, 0, 0, 0)
    assert rank_counts(len(p.J) for p in all_p if p.atlas) == (0, 35, 86, 107, 0, 0, 0, 0)
    low = [p for p in all_p if 2 <= len(p.J) <= 4]
    assert len({p.family for p in low}) == len({signature(p.B) for p in low}) == 42
    assert Counter(p.E.n for p in low) == {6: 50, 7: 91, 8: 154}

    # Independent comparison with every classical chamber and every flag pattern.
    classical = {B for r in range(1, 9) for B in based_classical(r)} & set(types)
    expected = {'length1', 'length2', 'A2', 'B2', 'BC2', 'five', 'N3', 'C3'}
    assert classical == {B for B, name in types.items() if name in expected}
    assert rank_counts(len(B[0]) for B in classical) == (2, 5, 4, 0, 0, 0, 0, 0)
    print('445 presentations, 378 based supports. Conceptual families 167, Appendix A 211.')
    return all_p, families


def align_coxeter(p, q, cols):
    """Move a source of the oriented internal Dynkin diagram to a sink.

    Its reflection commutes to the start of the word. Conjugating by that
    reflection moves the first letter to the end. Search the finite orientations.
    """
    word = tuple(cols[i].index(-1) for i in p.I)
    edges = [(i, j) for i, j in combinations(q.I, 2) if p.E.gram[i][j] == -1]
    start = frozenset((i, j) if word.index(i) < word.index(j) else (j, i) for i, j in edges)
    goal = frozenset(edges)
    todo = deque([(start, ())])
    seen = {start}
    while todo:
        orient, flips = todo.popleft()
        if orient == goal:
            A = p.E.coxeter(flips[::-1]) * Matrix(cols).T
            assert A * p.E.coxeter(p.I) == p.E.coxeter(q.I) * A
            return rows(A), flips
        for i in q.I:
            if any(v == i for _, v in orient):
                continue
            nxt = frozenset((v, u) if u == i else (u, v) for u, v in orient)
            if nxt not in seen:
                todo.append((nxt, flips + (i,)))
                seen.add(nxt)
    raise AssertionError((p.name, q.name, 'Coxeter conjugation'))


def transport(all_p):
    """Build trees of longest-parabolic moves and check the quotient on each edge."""
    by_key = {(p.E.n, p.J): p for p in all_p}
    groups = defaultdict(list)
    for p in all_p:
        groups[p.family, p.E.n].append(p)
        p.parent = None
    for group in groups.values():
        reached = set()
        for root in group:
            if root.J in reached:
                continue
            assert not reached or len(root.J) == 1, (root.name, 'disconnected family')
            reached.add(root.J)
            todo = deque([root])
            while todo:
                p = todo.popleft()
                for j in p.J:
                    cols = p.E.opposition(tuple(sorted((*p.I, j))))
                    opposites = {cols[i].index(-1) for i in p.I}
                    J = tuple(i for i in range(p.E.n) if i not in opposites)
                    q = by_key[p.E.n, J]
                    assert p.family == q.family
                    if J in reached:
                        continue
                    T = tuple(zip(*(project(cols[i], J) for i in p.J)))
                    assert abs(Matrix(T).det()) == 1
                    A, flips = align_coxeter(p, q, cols)
                    moved = {pair(mv(T, b)): {pair(mv(A, a)) for a in group} for b, group in p.fibres.items()}
                    assert moved == {b: set(group) for b, group in q.fibres.items()}
                    q.parent = p, j + 1, T, flips
                    reached.add(J)
                    todo.append(q)
        assert reached == {p.J for p in group}
    print('Longest-parabolic moves connect every same-ambient family in ranks 2 through 8.')


def check_units(all_p):
    full = [p for p in all_p if p.model.full]
    assert len(full) == 29 and sum(len(p.J) >= 2 for p in full) == 18
    hist = defaultdict(Counter)
    for p in all_p:
        p.endpoints = p.units()
        if p.family == 'spin3':
            assert not p.endpoints
        elif not p.model.full:
            count = len(p.endpoints)
            hist[len(p.J)][count] += 1
            if len(p.J) == 2:
                assert (count == 2) == (p.family in ('five', 'eight'))
    assert hist == {
        1: {1: 10},
        2: {2: 12, 3: 32, 4: 8},
        3: {4: 24, 6: 22, 7: 32, 8: 10, 9: 18},
        4: {8: 16, 9: 5, 10: 6, 11: 18, 12: 10, 14: 20, 15: 28, 16: 7, 18: 8},
        5: {10: 6, 15: 6, 16: 22, 24: 21, 25: 28},
        6: {16: 7, 27: 7, 32: 21},
        7: {28: 8},
    }
    assert Counter(p.family for p in all_p if p.family in ('five', 'eight', 'spin3')) == {
        'five': 6,
        'eight': 6,
        'spin3': 4,
    }
    print('Unit-fibre endpoints and all histograms agree, including all four spin exceptions.')


def per_label(p, exits, left, expected, skip=()):
    """Compare the disjoint sets at the actual degrees, separately on every label."""
    assert set(expected) | set(skip) == set(p.tags.values())
    data = {}
    for b, fibre in p.fibres.items():
        group = set(fibre)
        observed = tuple(len(group & gone) for _, gone in exits) + (len(group & left),)
        assert sum(observed) == len(fibre)
        tag = p.tags[b]
        if tag not in skip:
            assert observed == expected[tag], (p.name, b, tag, observed, expected[tag])
        data[b] = observed
    return data


def prime_fibres(p):
    """Checks the active prime, every binomial orbit size and every labelled value."""
    n = p.E.n
    rules = {
        'A5/i2': {'w3': (2, 1)},
        'D6/i2': {'w6': (2, 1)},
        'E7/i2': {'w6': (2, 1)},
        '2A2/i3': {'w1': (3, 1)},
        'A5/i3': {'w2': (3, 1)},
        'E6/i3': {'w1': (3, 1)},
        'A4/i5': {'w2': (5, 1), 'w1': (10, 2)},
        'A5/i6': {'w3': (2, 1), 'w2': (3, 1), 'w1': (6, 2)},
    }
    q = Coxeter(p)
    assert sorted(q.h.values()) == {2: [2], 3: [3], 5: [5], 6: [2, 3]}[q.m]
    # Ordered paths identify the dominant internal fundamental weights.
    paths = {}
    for K, h in q.h.items():
        assert len(K) == h - 1
        ends = [i for i in K if sum(p.E.gram[i][j] == -1 for j in K) <= 1]
        path = [min(ends)]
        while len(path) < len(K):
            (nxt,) = (j for j in K if j not in path and p.E.gram[path[-1]][j] == -1)
            path.append(nxt)
        paths[K] = path
    for beta, fibre in p.fibres.items():
        lam = p.dominant(fibre)
        active, size = [], 1
        for K, h in q.h.items():
            labels = project(lam, paths[K])
            assert all(x in (0, 1) for x in labels) and sum(labels) <= 1
            k = 1 + labels.index(1) if any(labels) else 0
            size *= comb(h, k)
            forms = primitive(p.E, K)[1]
            assert all(bool(k) == any(forms[a]) for a in fibre)
            if k:
                active.append(h)
        assert size == len(fibre)
        if active:
            assert size % max(active) == 0
            assert (size, size // max(active)) == rules[p.family][p.tags[beta]]
        else:
            assert p.tags[beta] == 'root' and size == 1 and q.move(fibre[0]) == fibre[0]
    # The index of the ordinary root lattice in the actual curve lattice.
    Q = Matrix([b for b in p.B if p.tags[b] == 'root']).T
    assert abs(hermite_normal_form(Q).det()) == q.m
    n0, kind, r, _, weights = next(row for row in ORDINARY if row[3] == p.family)
    assert (n, len(p.J)) == (n0, r)
    # Identify the ambient lattice in external and internal fundamental-weight
    # coordinates. Complementary endpoints give the two orientations of each A path.
    ext = diagram(r, kind)
    internal = p.E.G.extract(p.I, p.I)
    T = zeros(n)
    for i, j in enumerate(p.J):
        T[:r, j] = Matrix(p.marking[unit(r, i)])
    T[r:, :] = p.E.G[list(p.I), :]
    assert T.T * diag(ext.inv(), internal.inv()) * T == p.E.G
    target = hermite_normal_form(T)
    root_lattice = diag(ext, internal)
    factors = sorted(paths, key=q.h.get)
    for ends in product(*[{paths[K][0], paths[K][-1]} for K in factors]):
        glue = []
        for j, indices in zip(ends, weights):
            v = [int(i + 1 in indices) for i in range(r)]
            glue.append(Matrix(v + [int(i == j) for i in p.I]))
        if hermite_normal_form(Matrix.hstack(root_lattice, *glue)) == target:
            break
    else:
        raise AssertionError((p.name, 'ordinary glue generators'))


def mod_rank(vectors, prime):
    basis = {}
    for v in vectors:
        w = tuple(x % prime for x in v)
        for i in sorted(basis):
            w = tuple((x - w[i] * y) % prime for x, y in zip(w, basis[i]))
        if any(w):
            i = next(j for j, x in enumerate(w) if x)
            basis[i] = tuple(x * pow(w[i], -1, prime) % prime for x in w)
    return len(basis)


def fold(p, q, left, shorts, longs, dynkin, e):
    """Identify the labelled fixed and moving character matroids of a diagram fold."""
    folded = {a for a in left if project(a, p.J) in shorts | longs}
    ((kind, S, _),) = simple_parts(p.E, folded)
    assert kind == dynkin and {q.move(v) for v in S} == set(S)
    H = hermite_normal_form(Matrix(sorted(longs)).T)
    pivots = H.T.rref()[1]
    inv = H[list(pivots), :].inv()
    actual, labels, moving = [], [], defaultdict(list)
    for b in sorted(shorts | longs):
        roots = set(p.fibres[b]) & folded
        a = next(iter(roots))
        orbit = [a]
        for _ in range(e - 1):
            orbit.append(q.move(orbit[-1]))
        assert q.move(orbit[-1]) == a and set(orbit) == roots
        assert len(roots) == (e if b in shorts else 1)
        actual.append(tuple(map(sum, zip(*orbit))))
        labels.append(b)
        # The fractional coordinates in a basis of Z(long) give Q/Z(long).
        coord = inv * Matrix(project(b, pivots))
        assert H * coord == Matrix(b) and all((e * x).is_Integer for x in coord)
        residue = tuple(int(e * x) % e for x in coord)
        diff = add(a, q.move(a), -1)
        assert any(diff) == any(residue) == (b in shorts)
        if any(residue):
            # Identify proportional nonzero residue vectors.
            first = next(x for x in residue if x)
            line = tuple(x * pow(first, -1, e) % e for x in residue)
            moving[line].append(diff)
    ranks = Matrix(actual).rank(), Matrix(labels).rank()
    assert ranks[0] == ranks[1] == Matrix(actual).row_join(Matrix(labels)).rank()
    # Compare the metric on the actual fixed span with the inverse moment
    # metric of these same marked core labels, including cores of smaller rank.
    L = Matrix(labels)
    independent = L[:, L.rref()[1]]
    metric = independent * (independent.T * independent).inv() * independent.T
    gram = Matrix(actual) * p.E.G * Matrix(actual).T
    assert gram * metric[0, 0] == metric * gram[0, 0]
    if dynkin.startswith('D') and e == 2:
        # Each labelled pair is f_i +/- z. Recover the orthonormal coordinate
        # axes and their common moving axis in the ambient root lattice tensored with Q.
        fixed, odd = [], []
        for b in sorted(shorts):
            a, c = map(Matrix, sorted(set(p.fibres[b]) & folded))
            fixed.append((a + c) / 2)
            odd.append((a - c) / 2)
        z = odd[0]
        assert all(w == z or w == -z for w in odd)
        F = Matrix.hstack(*fixed, z)
        assert F.T * p.E.G * F == eye(F.cols) and q.C * F == Matrix.hstack(*fixed, -z)
        assert {pair(tuple(f + s * g)) for f, g in combinations(fixed + [z], 2) for s in (1, -1)} == folded
        assert {pair(add(b, c, s)) for b, c in combinations(shorts, 2) for s in (1, -1)} == longs
    if e == 3:
        # The two conjugate triality eigenspaces are each one-dimensional.
        diffs = [add(a, q.move(a), -1) for a in folded]
        assert len(moving) == 1 and Matrix(diffs).rank() == 2
    else:
        assert len(moving) <= 3
        for values in moving.values():
            assert Matrix(values).rank() == 1
        for size in range(1, len(moving) + 1):
            for subset in combinations(moving, size):
                assert Matrix([moving[v][0] for v in subset]).rank() == mod_rank(subset, e)


def of_type(p, left, *expected):
    parts = simple_parts(p.E, left)
    assert sorted(k for k, _, _ in parts) == sorted(expected), (p.name, [k for k, _, _ in parts])
    return parts


def scalar_weights(p, q, part, sign):
    """Centred scalar coordinates of an A path and the signed permutation on them."""
    kind, S, R = part
    assert kind.startswith('A')
    ends = [a for a in S if sum(p.E.inner(a, b) == -1 for b in S) <= 1]
    path = [min(ends)]
    while len(path) < len(S):
        (nxt,) = (b for b in S if b not in path and p.E.inner(path[-1], b) == -1)
        path.append(nxt)
    size = 1 + len(path)
    U = Matrix(path).T
    weights = [U * Matrix(range(size - 1, 0, -1)) / size]
    for i in range(len(path)):
        weights.append(weights[-1] - U[:, i])
    F = Matrix.hstack(*weights)
    assert F.T * p.E.G * F == eye(size) - Matrix.ones(size) / size
    assert {pair(tuple(a - b)) for a, b in combinations(weights, 2)} == R
    action = [weights.index(sign * q.C * f) for f in weights]
    projections = [project(tuple(f), p.J) for f in weights]
    return weights, action, projections


def exchanged_a2(p, q, left, external):
    parts = of_type(p, left, 'A2', 'A2')
    for (_, _, R), (_, _, T) in (parts, parts[::-1]):
        assert {q.move(a) for a in R} == T and all(q.move(q.move(a)) == a for a in R)
        assert {project(a, p.J) for a in R} == external


def five_coordinates(p, q, left):
    def fibre(tag):
        (b,) = (b for b in p.B if p.tags[b] == tag)
        return b, sorted(set(p.fibres[b]) & left)

    a, A = fibre('a')
    b, B = fibre('b')
    _, (kappa,) = fibre('2b')
    if p.E.n == 7:
        of_type(p, left, 'A2', 'A1', 'A1', 'A1')
        x, y = B
        assert add(x, y) == kappa and q.move(x) == y and q.move(y) == x
        assert all(p.E.inner(v, w) == 0 for v in A for w in B)
        assert all(p.E.inner(x, y) == 0 for x, y in combinations(A, 2))
        assert {q.move(v) for v in A} == set(A) and all(q.move(v) != v for v in A)
        return
    (part,) = of_type(p, left, 'A3')
    F, action, proj = scalar_weights(p, q, part, -1)
    zero = (0,) * len(b)
    assert Counter(proj) == Counter([b, scale(-1, b), zero, zero])
    i, j = [k for k, w in enumerate(proj) if w == zero]
    assert action[i] == i and action[j] == j and proj[action[proj.index(b)]] == scale(-1, b)
    (K,) = (K for K in p.parts if len(K) == 1)
    assert pair(tuple(F[i] - F[j])) == p.E.units[K[0]]
    assert F[proj.index(b)] - F[proj.index(scale(-1, b))] == Matrix(kappa)


def eight_coordinates(p, q, left):
    """Build the four orthonormal weights from the actual remaining roots, as in F3."""

    def fibre(tag):
        (b,) = (b for b in p.B if p.tags[b] == tag)
        return [Matrix(a) for a in sorted(set(p.fibres[b]) & left)]

    (kappa,) = fibre('2a')
    gamma, delta = fibre('2b')
    (a,) = (b for b in p.B if p.tags[b] == 'a')
    (b,) = (b for b in p.B if p.tags[b] == 'b')
    parts = of_type(p, left, *(['D4', 'A1'] if p.E.n == 7 else ['D4']))
    (R,) = (R for name, _, R in parts if name == 'D4')
    (internal,) = (v for v in R if not any(project(v, p.J)))
    assert internal in p.E.units
    e = Matrix(internal)
    F = Matrix.hstack(kappa + e, kappa - e, gamma + delta, gamma - delta) / 2
    assert F.T * p.E.G * F == eye(4)
    assert q.C * F == Matrix.hstack(F[:, 1], F[:, 0], F[:, 2], -F[:, 3])
    assert [project(tuple(F[:, i]), p.J) for i in range(4)] == [a, a, scale(2, b), (0, 0)]
    assert {pair(tuple(F[:, i] + s * F[:, j])) for i, j in combinations(range(4), 2) for s in (-1, 1)} == R
    for v in left - R:
        assert v in p.E.units and not any(project(v, p.J)) and q.move(v) == scale(-1, v)


def quadratic_blocks(p, q, left, longs):
    (part,) = of_type(p, left, 'A5')
    F, action, labels = scalar_weights(p, q, part, 1)
    assert sorted(Counter(labels).values()) == [2, 2, 2]
    axes = set(labels)
    assert {pair(add(v, w, -1)) for v, w in combinations(axes, 2)} == longs
    internal = set()
    for i, j in enumerate(action):
        assert j != i and action[j] == i and labels[i] == labels[j]
        internal.add(pair(tuple(F[i] - F[j])))
    assert internal == {p.E.units[K[0]] for K in p.parts if len(K) == 1}


def anchors(p, q, left):
    """The marked A5 and A4 scalar weights of the BC2 competitors."""
    count_zero = 2 if p.E.n == 7 else 1
    (part,) = of_type(p, left, 'A' + str(3 + count_zero))
    F, action, labels = scalar_weights(p, q, part, -1)
    axes = {b for b in p.B if p.tags[b] == 'axis'}
    zero = (0, 0)
    assert Counter(labels) == Counter(list(axes) + [scale(-1, b) for b in axes] + [zero] * count_zero)
    assert all((i == j) == (labels[i] == zero) for i, j in enumerate(action))
    assert all(labels[j] == scale(-1, labels[i]) for i, j in enumerate(action))
    if count_zero == 2:
        i, j = [k for k, b in enumerate(labels) if b == zero]
        (K,) = (K for K in p.parts if len(K) == 1)
        assert pair(tuple(F[i] - F[j])) == p.E.units[K[0]]


def quadratic_signs(p):
    """The complete coefficients on orthogonal internal A1's, before any matching."""
    I = p.I
    assert all(len(K) == 1 for K in p.parts)
    masks = {}
    for b, fibre in p.fibres.items():
        vectors = {project(p.E.weights[a], I) for a in fibre}
        mask = tuple(i for i, x in enumerate(next(iter(vectors))) if x)
        choices = [(-1, 1) if i in mask else (0,) for i in range(len(I))]
        assert vectors == set(product(*choices)) and len(fibre) == len(vectors)
        masks[b] = mask
    return masks


def matched_cubics(p, q):
    """Every possible short-fibre cancellation has one common ratio modulo mu_3."""
    K, T = p.parts
    a, b = [primitive(p.E, V)[1] for V in (K, T)]
    for sign in (1, -1):
        if all(
            any(a[v] == scale(-sign, b[v]) for v in p.fibres[label]) for label in p.B if p.tags[label] == 'short'
        ):
            break
    else:
        raise AssertionError((p.name, 'no common cubic match'))
    for label, roots in p.fibres.items():
        if p.tags[label] == 'long':
            assert all(not any(a[v]) and not any(b[v]) for v in roots)
            continue
        X, Y = {a[v] for v in roots}, {b[v] for v in roots}
        assert len(X) == 3 and (0, 0) not in X
        assert {(-y, x - y) for x, y in X} == X  # multiplication by z modulo z^2+z+1
        assert X == {scale(-sign, w) for w in Y}
        assert {(a[v], b[v]) for v in roots} == set(product(X, Y))
    return {K: 1, T: sign}


def line_attachment(p, q):
    masks = quadratic_signs(p)
    core = {pair(p.marking[b]): b for b in p.B if p.tags[b] == 'short'}
    for b, mask in masks.items():
        tag = p.tags[b]
        assert len(mask) == {'short': 2, 'long': 0, 'mixed': 1, 'line': 3, 'double': 0}[tag]
        if tag == 'mixed':
            raw = p.marking[b]
            delta = core[pair(raw[:-1] + (0,))]
            assert set(mask).isdisjoint(masks[delta])

    # The three classes are the coordinate shorts and the two parities of half-signs.
    def short_class(v):
        return 'axis' if 2 in map(abs, v) else prod(v[:4])

    classes = defaultdict(set)
    for v, b in core.items():
        classes[short_class(v)].add(masks[b])
    assert len(classes) == 3 and len({next(iter(s)) for s in classes.values()}) == 3
    assert all(len(s) == 1 for s in classes.values())
    shorts = set(core.values())
    longs = {b for b in p.B if p.tags[b] == 'long'}
    reports = []
    for exceptional in (None, 0, 1, 2):
        coeff = {K: (-2 if i == exceptional else 1) for i, K in enumerate(p.parts)}
        exits, (left,) = q.cut([coeff])
        expected = {
            'mixed': (2, 0),
            'line': (8, 0) if exceptional is None else (6, 2),
            'double': (0, 1),
            'long': (0, 1),
        }
        data = per_label(p, exits, left, expected, skip={'short'})
        (v,) = (b for b in p.B if p.tags[b] == 'double')
        (kappa,) = p.fibres[v]
        assert q.move(kappa) == kappa
        active = {b for b in shorts if exceptional not in masks[b]}
        assert all(data[b] == ((2, 2) if b in active else (4, 0)) for b in shorts)
        if exceptional is None:
            of_type(p, left, 'E6', 'A1')
            fold(p, q, left, shorts, longs, 'E6', 2)
        else:
            of_type(p, left, 'D5', 'A2')
            assert len(active) == 4
            fold(p, q, left, active, longs, 'D5', 2)
            (b,) = (b for b in p.B if p.tags[b] == 'line')
            x, y = sorted(left & set(p.fibres[b]))
            assert add(x, y) in (left & set(p.fibres[scale(2, b)]))
            assert q.move(x) == y and q.move(y) == x
        reports.append(([coeff], exits, left))
    return reports


def attachments(p):
    """Compare labelled exits at each activation degree and the surviving root actions."""
    f, n = p.family, p.E.n
    q = Coxeter(p)
    m = q.m
    top = {K: 1 for K, h in q.h.items() if h == max(q.h.values())}
    stages = [top]
    if f == 'F4+line':
        assert n == 8 and m == 2 and len(top) == 3
        return q, line_attachment(p, q)
    if f == 'G2' and len(top) == 2:
        top = matched_cubics(p, q)
        stages = [top]
    if (f == 'diagonal' and n == 6) or (f == '2short-G2' and n == 8):
        stages.append({K: 1 for K in p.parts if K not in top})
    exits, survivors = q.cut(stages)
    left = survivors[-1]

    def labels(tag):
        return {b for b in p.B if p.tags[b] == tag}

    def check(expected):
        return per_label(p, exits, left, expected)

    if f in ('spin3', 'spin5', 'spin6', 'B4+line'):
        r = 4 if f == 'B4+line' else len(p.J)
        assert m == {'spin3': {7: 4, 8: 8}, 'spin5': {8: 4}, 'spin6': {8: 2}, 'B4+line': {7: 2}}[f][n]
        expected = {'short': (m, 2), 'long': (0, 1), 'spin': (m * (2 if r == 3 else 1), 0)}
        if f == 'B4+line':
            expected['line'] = (0, 1)
        check(expected)
        fold(p, q, left, labels('short'), labels('long'), 'D' + str(r + 1), 2)
        extra = f == 'B4+line' or (f == 'spin3' and n == 7)
        parts = of_type(p, left, 'D' + str(r + 1), *(['A1'] if extra else []))
        if extra:
            (v,) = next(R for k, _, R in parts if k == 'A1')
            if f == 'spin3':
                (K,) = (K for K in p.parts if len(K) == 1)
                assert v == p.E.units[K[0]] and q.move(v) == scale(-1, v)
            else:
                assert project(v, p.J) in labels('line') and q.move(v) == v
        if len(top) == 2:
            masks = quadratic_signs(p)
            assert all(
                len(v) == {'short': 2, 'long': 0, 'spin': 1, 'line': 0}[p.tags[b]] for b, v in masks.items()
            )
    elif f == 'diagonal':
        if n == 6:
            assert m == 6 and [d for d, _ in exits] == [2, 3]
            check({'short': (6, 0, 0), 'plus': (3, 0, 0), 'diagonal': (0, 2, 0), 'minus': (0, 0, 1)})
        else:
            assert n == 7 and m == 5
            check({'short': (10, 0), 'plus': (5, 0), 'diagonal': (5, 0), 'minus': (0, 1)})
        of_type(p, left, 'A2')
        assert all(q.move(a) == a for a in left)
    elif f in ('five', 'eight', 'nine'):
        if f == 'five':
            assert m == {6: 4, 7: 6}[n]
            check(
                {
                    'a': (2 * m, 0 if n == 6 else 3),
                    'b': (2 * m, 4) if n == 6 else (3 * m, 2),
                    '2b': (0, 1),
                    'ab': (m, 0),
                }
            )
            five_coordinates(p, q, left)
        elif f == 'eight':
            assert m == {7: 4, 8: 8}[n]
            check({'b': (4 * m, 0), 'ab': (2 * m, 0), '2b': (m, 2), 'a': (2 * m, 4), '2a': (0, 1), 'a2b': (0, 2)})
            eight_coordinates(p, q, left)
        else:
            assert n == 8 and m == 6
            check(
                {
                    'w': (24, 6),
                    '2w': (12, 3),
                    '3w': (0, 2),
                    'q': (18, 2),
                    '2q': (0, 1),
                    'qw': (12, 0),
                    'q2w': (6, 0),
                }
            )
            nine_characters(p, q, left)
    elif f == '2short-G2':
        assert m == 6
        if n == 7:
            assert [d for d, _ in exits] == [2]
            check({'short': (12, 0), 'double': (3, 0), 'long': (0, 4)})
            quadratic_blocks(p, q, left, labels('long'))
        else:
            assert n == 8 and [d for d, _ in exits] == [1, 2]
            of_type(p, survivors[0], 'E6')
            check({'short': (18, 6, 0), 'double': (0, 3, 0), 'long': (6, 0, 2)})
            exchanged_a2(p, q, left, labels('long'))
    elif f in ('G2', 'F4', 'C3', 'N3'):
        cover = {'G2': {6: 3, 7: 6, 8: 12}, 'F4': {7: 2, 8: 6}, 'C3': {7: 6}, 'N3': {6: 4}}
        assert m == cover[f][n]
        e = 3 if f == 'G2' else 2
        long_tag = 'double' if f in ('C3', 'N3') else 'long'
        expected = {'short': ((e - 1) * m, e), long_tag: (0, 1)}
        if f == 'N3':
            expected['mixed'] = (m, 0)
        check(expected)
        kind = {'G2': 'D4', 'F4': 'E6', 'C3': 'A5', 'N3': 'A3'}[f]
        of_type(p, left, kind)
        fold(p, q, left, labels('short'), labels(long_tag), kind, e)
        if f == 'F4' and len(top) == 3:
            masks = quadratic_signs(p)
            assert all(len(masks[b]) == (2 if tag == 'short' else 0) for b, tag in p.tags.items())
            assert {masks[b] for b in labels('short')} == set(combinations(range(3), 2))
    elif f == 'A2':
        assert n == m == 6
        check({'root': (6, 2)})
        exchanged_a2(p, q, left, set(p.B))
    elif f == 'B2':
        assert m == {6: 5, 7: 8}[n]
        counts = per_label(p, exits, left, {'axis': (2 * m, 0)}, skip={'pair'})
        long_counts = {counts[b] for b in labels('pair')}
        assert long_counts == {(0, 1), (m, 0 if n == 6 else 2)}
        if p.name in ('E6/12', 'E7/16'):
            fixed = (1, 0) if n == 6 else (2, 1)
            assert counts[fixed] == (0, 1)
        of_type(p, left, *(['A1'] if n == 6 else ['A1'] * 3))
        for b in labels('pair'):
            group = set(p.fibres[b]) & left
            if group:
                first = next(iter(group))
                assert {first, q.move(first)} == group
    elif f == 'BC2':
        assert m == {7: 6, 8: 10}[n]
        check({'axis': (12, 4) if n == 7 else (30, 2), 'double': (0, 1), 'pair': (m, 2)})
        anchors(p, q, left)
    else:
        raise AssertionError((p.name, f, 'unhandled attachment'))

    # The complete eigenspaces in the ambient Cartan at the selected degrees.
    # Every primitive line specified above is mandatory and internally regular.
    z = Symbol('z')
    poly = Poly(q.C.charpoly(z).as_expr(), z)
    required = {d: len(coeff) for coeff, (d, _) in zip(stages, exits)}
    for degree in range(1, 1 + max(required)):
        h = m // gcd(m, degree)
        phi = Poly(cyclotomic_poly(h, z), z)
        multiplicity = 0
        rem = poly
        while rem.rem(phi).is_zero:
            rem = rem.exquo(phi)
            multiplicity += 1
        assert multiplicity == required.get(degree, 0), (p.name, degree)
    return q, [(stages, exits, left)]


def nine_characters(p, q, left):
    """Compare all E8 roots in the A5+A2+A1 model, including the two radial characters."""
    (K,) = (K for K in p.parts if len(K) == 5)
    (singleton,) = (K[0] for K in p.parts if len(K) == 1)
    internal = {a for a in p.E.roots if not any(a[i] for i in range(8) if i not in K)}
    (part,) = of_type(p, internal, 'A5')
    F, action, _ = scalar_weights(p, q, part, 1)
    cycle = [0]
    while action[cycle[-1]] not in cycle:
        cycle.append(action[cycle[-1]])
    assert len(cycle) == 6
    weights = Matrix.hstack(*(F[i] for i in cycle))
    actual = set()
    for a in p.E.roots:
        b = project(a, p.J)
        w, q0 = p.marking[b] if any(b) else (0, 0)
        x = tuple(6 * t for t in Matrix([p.E.weights[a]]) * weights)
        item = x + (w, p.E.weights[a][singleton], q0)
        actual.update([item, scale(-1, item)])

    # Coordinates are (6 times the six traceless A5 coefficients, w, U, q).
    # The three A2 weights evaluate to w+U, w-U, -2w. The A1 weights are +/-q.
    H = [(1, 1), (1, -1), (-2, 0)]
    zero = (0,) * 6
    model = {scale(6, add(unit(6, i), unit(6, j), -1)) + (0, 0, 0) for i, j in permutations(range(6), 2)}
    model.update(zero + add(a, b, -1) + (0,) for a, b in permutations(H, 2))
    model.update([zero + (0, 0, 2), zero + (0, 0, -2)])
    for k in range(1, 6):
        for subset in combinations(range(6), k):
            x = tuple(6 * int(i in subset) - k for i in range(6))
            for T in combinations(H, (-k) % 3):
                w, U = (sum(v[i] for v in T) for i in range(2))
                for q0 in ((1, -1) if k % 2 else (0,)):
                    model.add(x + (w, U, q0))
    assert len(model) == 240
    assert any({v[:6] + (s * v[6],) + v[7:] for v in actual} == model for s in (1, -1))
    phases = ((1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1))
    for k, expected in [(2, {(0, 3), (1, 4), (2, 5)}), (3, {(0, 2, 4), (1, 3, 5)})]:
        assert {
            T for T in combinations(range(6), k) if all(sum(phases[i][j] for i in T) == 0 for j in (0, 1))
        } == expected
    assert all(
        (a in left)
        == all(
            sum(p.E.weights[a][j] * weights[j, i] * phases[i][t] for j in range(8) for i in range(6)) == 0
            for t in (0, 1)
        )
        for a in p.E.roots
    )


def specify_frame(p, transform):
    """Check an ordered frame printed in the paper against the entire signed model."""
    M = Matrix(transform)
    integral = Matrix(p.model.lattice).inv() * M
    assert all(x.is_Integer for x in integral) and abs(integral.det()) == 1, p.name
    p.marking = {b: tuple(M * Matrix(b)) for b in p.B}
    assert {pair(v) for v in p.marking.values()} == set(p.model.tags), p.name
    p.tags = {b: p.model.tags[pair(v)] for b, v in p.marking.items()}


def check_partial_classical_markings(presentations):
    """The three ordered nonterminal flags in the rank-three table of Appendix B.3.3."""
    expected = {(2,3): {'E6/125','E6/145'},
                (1,3): {'E6/126','E6/456'},
                (1,2): {'E6/156'}}
    axes = [eye(3)[:,j] for j in range(3)]
    for flags, names in expected.items():
        last = 2*axes[2] if 3 in flags else axes[1]+axes[2]
        basis = Matrix.hstack(axes[0]-axes[1], axes[1]-axes[2], last)
        roots = [a + sign*b for a,b in combinations(axes,2) for sign in (-1,1)]
        roots.extend(2*axes[i-1] for i in flags)
        coordinates = [basis.inv()*v for v in roots]
        assert all(x.is_Integer and x >= 0 for v in coordinates for x in v)
        key, _ = based_form(tuple(sorted(tuple(map(int,v)) for v in coordinates)))
        matches = {p.name for p in presentations if p.key == key}
        assert matches == names, (flags,matches,names)


def printed_chambers(all_p, families):
    by_name = {p.name: p for p in all_p}

    def frames(name, specs):
        used = set()
        for cols, presentations in specs:
            for item in presentations.split():
                ambient, order = item.split('/')
                nodes = [int(c) for c in order]
                p = by_name['E' + ambient + '/' + ''.join(sorted(order))]
                assert p.family == name
                M = Matrix([cols[nodes.index(i)] for i in sorted(nodes)]).T
                specify_frame(p, M)
                used.add(p.name)
        assert used == {p.name for p in families[name]}

    frames('five', [([(1, -1), (0, 1)], '6/14 6/52 7/67'), ([(1, 0), (-1, 1)], '6/26 6/46 7/71')])
    frames(
        'eight',
        [([(1, -2), (0, 1)], '7/13 8/75'), ([(1, -1), (-1, 2)], '7/32 8/56'), ([(1, 0), (-1, 1)], '7/25 8/61')],
    )
    frames('nine', [([(1, 0), (-2, 1)], '8/27'), ([(-1, 1), (2, -1)], '8/28'), ([(1, -1), (0, 1)], '8/68')])
    frames('2short-G2', [([(1, 0), (0, 1)], '7/53 8/15')])
    frames('G2', [([(1, 0), (0, 1)], '6/63 7/12 8/76')])
    frames(
        'spin3',
        [
            ([(0, 2, -2), (2, -2, 0), (-1, 1, 1)], '7/123 8/765'),
            ([(0, 2, -2), (0, 0, 2), (1, -1, -1)], '7/125 8/761'),
        ],
    )
    frames(
        'diagonal',
        [
            ([(2, 0, 2), (0, 2, 0), (0, -2, -2)], '6/146 6/526 7/671'),
            ([(2, 2, 2), (0, -2, 0), (0, 2, -2)], '6/136 6/536 7/621'),
            ([(2, -2, 0), (0, 2, 2), (0, 0, -2)], '6/124 6/542 7/657'),
            ([(2, -2, 0), (0, 2, -2), (0, 0, 2)], '6/123 6/543 7/654'),
            ([(2, 2, 2), (-2, 0, -2), (2, -2, 0)], '6/236 6/436 7/721'),
        ],
    )
    # The columns on the left of these equations are 2u,2v,2h or 2u,2v,2w.
    for name, directions in [
        ('E6/125', [(1, 0, 0), (1, 2, 0), (1, 2, 2)]),
        ('E7/156', [(0, 0, 1), (0, 2, 1), (2, 2, 1)]),
    ]:
        specify_frame(by_name[name], 4 * Matrix(directions).T.inv())
    for name, targets in {
        'A2': '6/15',
        'B2': '6/12 6/16 6/45 6/56 7/16 7/56',
        'BC2': '7/15 8/17',
        'C3': '7/156',
        'F4': '7/1235 8/1567',
        'N3': '6/125 6/145 6/126 6/456 6/156',
    }.items():
        assert {p.name for p in families[name]} == {'E' + v for v in targets.split()}
    for name, n in [('spin5', 7), ('spin6', 21), ('B4+line', 15), ('F4+line', 21), ('diagonal', 5)]:
        assert len({p.key for p in families[name]}) == n


def numerical_fibres(all_p, show):
    prime_names = {row[3] for row in ORDINARY}
    prime_count = folded_count = 0
    for p in all_p:
        if p.family in prime_names:
            prime_fibres(p)
            prime_count += 1
            if p.name == show:
                q = Coxeter(p)
                stages = [{K: 1} for K in sorted(q.h, key=q.h.get, reverse=True)]
                exits, left = q.cut(stages)
                show_cut(p, q, stages, exits, left[-1])
        elif not (p.atlas or p.family.startswith('length') or not p.I):
            q, runs = attachments(p)
            folded_count += 1
            if p.name == show:
                for stages, exits, left in runs:
                    show_cut(p, q, stages, exits, left)
    assert (prime_count, folded_count) == (73, 120)
    print(f'Prime fibre values checked in {prime_count} presentations in eight lattice models.')
    print(f'Labelled root counts and Coxeter actions checked in {folded_count} other presentations.')


def show_cut(p, q, stages, exits, left):
    print(p.name, p.family, 'cover', q.m)
    for coeff, (degree, _) in zip(stages, exits):
        h = q.h[next(iter(coeff))]
        evaluations = [primitive(p.E, K)[1] for K in coeff]
        forms = Matrix(
            [[dot(col, coeff.values()) for col in zip(*(f[e] for f in evaluations))] for e in p.E.units]
        )
        # Rows are indexed by ambient simple roots, columns by powers of zeta_h.
        print('degree', degree, 'primitive vector in Q(zeta_%d)' % h, rows(p.E.G.inv() * forms))
    print('positive simple roots of the annihilator and their Coxeter images')
    for kind, S, _ in simple_parts(p.E, left):
        print(kind, [(a, q.move(a)) for a in S])
    for b in p.B:
        group = set(p.fibres[b])
        print(
            b,
            p.tags[b],
            'exits',
            [(d, len(group & gone)) for d, gone in exits],
            'surviving',
            sorted(group & left),
        )


def check_support_images(presentations):
    """Compare auxiliary folded and classical images in Appendix B and Section 6.

    These comparisons use the same unbounded root-order engine as the 27 rows.
    Coordinates in the statement of a family come from its integral marking.
    """
    import z3
    from atlas import Queries
    from cartan import cartan_image
    from rows import D, T, bc_condition, contact, folded, repeated_min

    expected_counts = {'A2': 1, 'B2': 6, 'BC2': 2, 'C3': 1, 'N3': 5,
                       'F4': 2, 'G2': 3, 'five': 6, 'eight': 6, 'nine': 3,
                       '2short-G2': 2, 'spin3': 4}
    counts = Counter()
    for p in presentations:
        family = p.family
        if family not in expected_counts:
            continue
        values = {b: z3.Int('n_' + '_'.join(map(str, b))) for b in p.B}
        groups = defaultdict(list)
        for b in p.B:
            groups[p.tags[b]].append(values[b])

        def value(tag):
            single, = groups[tag]
            return single

        def constant(tag, k):
            return z3.And([v == k for v in groups[tag]])

        if family in ('C3', 'G2', 'F4'):
            rule, _ = folded(p.B, list(values.values()), family)
        elif family == 'A2':
            rule = contact(p.B, [v - 1 for v in values.values()])
        elif family == 'B2':
            _, shorts = folded(p.B, list(values.values()), 'B2')
            rule = z3.And([v == 2 for v in shorts])
        elif family == 'BC2':
            rule = bc_condition(p.B, list(values.values()))
        elif family == 'N3':
            core = [b for b in p.B if p.tags[b] != 'mixed']
            rule = z3.And(folded(core, [values[b] for b in core], 'B2')[0],
                           constant('mixed', 1))
        elif family == 'spin3':
            core = [b for b in p.B if p.tags[b] != 'spin']
            rule = z3.And(folded(core, [values[b] for b in core], 'B3')[0],
                           constant('spin', 2))
        elif family == 'five':
            rule = z3.And(value('a') == 2 if p.E.n == 6 else value('a') >= 3,
                           D(value('b'), value('2b')), constant('ab', 1))
        elif family == 'eight':
            a, q = value('a'), value('2b')
            rule = z3.And(D(a, value('2a')), value('b') == 4, q >= 2,
                           constant('ab', 2), constant('a2b', 1), z3.Or(a == 4, q == 2))
        elif family == 'nine':
            rule = z3.And(T(value('w'), value('2w')), value('3w') == 1,
                           D(value('q'), value('2q')), constant('q2w', 1), constant('qw', 2))
        else:  # doubled short G2
            longs = groups['long']
            rule = z3.And(constant('short', 4 if p.E.n == 7 else 5),
                           constant('double', 1), *[x >= 2 for x in longs], repeated_min(*longs))
        actual = z3.Or(cartan_image(p.E.n, p.J, values))
        error = (z3.And(actual, z3.Not(rule)) if family in ('B2', 'BC2')
                 else z3.Xor(actual, rule))
        Queries(values, 0).check(error, z3.unsat, p.name + ' ' + family)
        counts[family] += 1
    if counts != expected_counts:
        raise ValueError(f'Unexpected numbers of presentations in the overlap checks: {counts}')
    print(f'{sum(counts.values())} additional exceptional images checked over all '
          'positive multiplicities (classical containments for B2 and BC2).')


def check_separator_polynomial():
    """Evaluate the explicit row 3f polynomial in the Euclidean E7 of the note."""
    roots = set()
    for i, j in combinations(range(8), 2):
        for a, b in product((-2, 2), repeat=2):
            v = [0] * 8
            v[i], v[j] = a, b
            roots.add(tuple(v))
    roots.update(v for v in product((-1, 1), repeat=8) if prod(v) == 1)
    roots = [v for v in roots if v[3] == v[4]]  # All root coordinates are doubled.
    linear = (0, 2, -2, 1, 1, 2, 0, 0)
    quadratic = (-2, 1, 1, 0, 0, 0, 0, 6)
    orders = defaultdict(list)
    internal = 0
    for v in roots:
        doubled = (v[1]+v[2], v[0]+v[7], v[7]-v[0])
        assert all(a % 2 == 0 for a in doubled)
        beta = tuple(a//2 for a in doubled)
        if dot(v, linear):
            order = 1
        elif dot(v, quadratic):
            order = 2
        else:
            raise ValueError(f'The E7 witness vanishes on root {v}/2')
        if not any(beta):
            assert order == 1
            internal += 1
        elif pair(beta) == beta:
            orders[beta].append(order)
    assert len(roots) == 126 and internal == 8 and len(orders) == 16
    profiles = {(2,): [2], (1,1): [1,1,2,2], (1,): [1]*6+[2,2], (1,1,1): [1,1]}
    for beta, exits in orders.items():
        assert sorted(exits) == profiles[tuple(sorted(abs(v) for v in beta if v))]
    print('Section 4.5: the row 3f E7 polynomial gives the prescribed orders on all 126 signed roots.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--show', metavar='En/J', help='print a regenerated presentation')
    parser.add_argument('--endpoints', action='store_true', help='print all labelled unit endpoints')
    from pathlib import Path
    parser.add_argument('--paper', type=Path, help='read the Appendix A columns from this TeX source')
    args = parser.parse_args()
    if not __debug__:
        raise SystemExit('Run without -O so all mathematical assertions are enabled.')
    all_p, families = inventory(args.paper)
    transport(all_p)
    check_units(all_p)
    check_partial_classical_markings(all_p)
    check_support_images(all_p)
    check_separator_polynomial()
    printed_chambers(all_p, families)
    numerical_fibres(all_p, args.show)
    if args.endpoints:
        for p in all_p:
            print(p.name, 'unit endpoints', sorted(p.endpoints.items()))
    if args.show:
        p = next((p for p in all_p if p.name == args.show), None)
        if p is None:
            parser.error('expected a name such as E7/125 with increasing one-based nodes')
        print(p.name, p.family, 'unit endpoints', p.endpoints)
        print('coordinate order to canonical positive support', [i + 1 for i in p.basis_order])
        print('images of chamber generators', [p.marking[unit(len(p.J), i)] for i in range(len(p.J))])
        print('positive label, model coordinates, fibre size')
        for b in p.B:
            print(b, p.marking[b], len(p.fibres[b]))
        while p.parent:
            prev, wall, matrix, flips = p.parent
            print(
                prev.name,
                'wall',
                wall,
                'to',
                p.name,
                'quotient matrix',
                matrix,
                'subsequent internal reflections',
                [i + 1 for i in flips],
            )
            p = prev


if __name__ == '__main__':
    main()
