"""The printed Appendix A columns and their indexed numerical conditions.

The variable indices in printed_rule start at one, as in Appendix A. The
predicates here supply P in Section 4.4; cartan.py constructs Q independently.
"""

from dataclasses import dataclass
from functools import cache
from itertools import combinations, product
import re

import sympy as sp
from sympy.matrices.normalforms import hermite_normal_form
import z3

from cartan import require, sign_pair


ROW_NAMES = tuple(str(r) + letter for r, letters in
                  [(2, "abcdefgh"), (3, "abcdefghijk"), (4, "abcdefgh")]
                  for letter in letters)


@dataclass
class Row:
    name: str
    fixed: dict
    variable: tuple

    @property
    def support(self):
        return tuple(sorted((*self.fixed, *self.variable)))

    def predicate(self, numbers):
        xs = [numbers[t] for t in self.variable]
        return z3.simplify(z3.And(
            [numbers[t] == k for t, k in self.fixed.items()] +
            [printed_rule(self.name, self.variable, xs)]
        ))


PRINTED_SUPPORT_TABLES = r"""
\label{tab:atlas2}
2a & 6 & \AtlasGroup{1}{02 10 13}\AtlasGroup{2}{11 12}\AtlasGroup{4}{01} & \AtlasVars{} \\[2pt]
2b & 7 & \AtlasGroup{1}{02 10 13}\AtlasGroup{3}{11 12}\AtlasGroup{5}{01} & \AtlasVars{23} \\[2pt]
2c & 8 & \AtlasGroup{1}{01 30 41}\AtlasGroup{2}{11 31} & \AtlasVars{10 20 21} \\[2pt]
2d & 10 & \AtlasGroup{1}{01 30 51}\AtlasGroup{2}{11 41}\AtlasGroup{3}{20 21 31}\AtlasGroup{6}{10} & \AtlasVars{52} \\[2pt]
2e & 10 & \AtlasGroup{1}{10 14 23 25} & \AtlasVars{01 02 11 12 13 24} \\[2pt]
2f & 11 & \AtlasGroup{1}{10 15 24 26}\AtlasGroup{2}{02 11 14}\AtlasGroup{4}{01 12 13} & \AtlasVars{25} \\[2pt]
2g & 12 & \AtlasGroup{1}{01 40 61}\AtlasGroup{2}{11 30 51}\AtlasGroup{3}{21 41}\AtlasGroup{5}{20}\AtlasGroup{6}{10} & \AtlasVars{31 62} \\[2pt]
2h & 14 & \AtlasGroup{1}{22 30 62 63}\AtlasGroup{2}{01 32 41 52}\AtlasGroup{4}{11 31} & \AtlasVars{10 20 21 42} \\[2pt]
\end{longtable}
\label{tab:atlas3}
3a & 11 & \AtlasGroup{1}{001 021 100 111 120 131} & \AtlasVars{010 011 020 110 121} \\[2pt]
3b & 12 & \AtlasGroup{1}{001 010 110 201 212 312}\AtlasGroup{2}{100 211} & \AtlasVars{101 111 202 311} \\[2pt]
3c & 13 & \AtlasGroup{1}{010 012 110 112 121 123} & \AtlasVars{001 011 100 111 122 133 233} \\[2pt]
3d & 14 & \AtlasGroup{1}{001 021 022 100 110 133 143}\AtlasGroup{2}{111 121 122 132}\AtlasGroup{4}{011} & \AtlasVars{010 243} \\[2pt]
3e & 14 & \AtlasGroup{1}{001 011 111 131 231 241} & \AtlasVars{010 100 110 120 121 130 230 242} \\[2pt]
3f & 16 & \AtlasGroup{1}{100 120 122 142} & \AtlasVars{001 010 011 020 021 022 110 111 121 131 132 242} \\[2pt]
3g & 17 & \AtlasGroup{1}{124 134 135 234 235 245 246}\AtlasGroup{2}{001 011 012 111 112 122}\AtlasGroup{4}{123} & \AtlasVars{010 100 110} \\[2pt]
3h & 18 & \AtlasGroup{1}{001 010 110 202 212 302 311 413 513}\AtlasGroup{3}{100 201 211 312}\AtlasGroup{5}{101} & \AtlasVars{111 301 412 523} \\[2pt]
3i & 20 & \AtlasGroup{1}{001 201 221 311 321 423 523 533}\AtlasGroup{2}{100 110 312 322}\AtlasGroup{4}{211} & \AtlasVars{010 101 111 202 212 222 422} \\[2pt]
3j & 21 & \AtlasGroup{1}{010 011 221 300 410 411 621}\AtlasGroup{2}{110 111 310 311 321 521} & \AtlasVars{001 100 200 210 211 421 631 632} \\[2pt]
3k & 23 & \AtlasGroup{1}{022 100 120 133 153 242 243 263 264}\AtlasGroup{2}{001 021 111 122 131 142}\AtlasGroup{4}{011 121 132} & \AtlasVars{010 020 110 143 253} \\[2pt]
\end{longtable}
\label{tab:atlas4}
4a & 17 & \AtlasGroup{1}{0001 0010 0110 0121 1110 1121 1221 1232} & \AtlasVars{0011 0100 0111 0122 1000 1100 1111 1122 1222} \\[2pt]
4b & 18 & \AtlasGroup{1}{0001 1000 1100 1110 2101 2111 2211 3212} & \AtlasVars{0010 0100 0110 1001 1101 1111 2102 2112 2212 3211} \\[2pt]
4c & 21 & \AtlasGroup{1}{0001 0010 0110 0121 0122 1110 1121 1122 1221 1222 1233}\AtlasGroup{2}{0011 0111 1111 1232} & \AtlasVars{0100 1000 1100 1243 1343 2343} \\[2pt]
4d & 23 & \AtlasGroup{1}{0001 0011 0211 0221 1000 1100 1110 1210 1222 1322 1332 1432} & \AtlasVars{0010 0100 0110 0111 0210 0222 1111 1211 1221 1321 2432} \\[2pt]
4e & 29 & \AtlasGroup{1}{0001 0100 0110 1100 1110 2001 2102 2112 2211 3102 3112 3211 4213 5213}\AtlasGroup{2}{1000 2101 2111 3212} & \AtlasVars{0010 1001 1101 1111 2002 2212 3101 3111 4212 5313 5323} \\[2pt]
4f & 30 & \AtlasGroup{1}{0001 0010 0100 0110 0121 0122 1100 1110 1121 1122 1211 1233 1332 1343 2332 2343 2443 2454} & \AtlasVars{0011 0111 1000 1111 1210 1221 1222 1232 1243 1333 2333 2453} \\[2pt]
4g & 33 & \AtlasGroup{1}{0122 1122 1222 1233 1242 1243 1342 1343 1353 2342 2343 2353 2453 2463 2464}\AtlasGroup{2}{0001 0011 0111 0121 1111 1121 1221 1231}\AtlasGroup{4}{1232} & \AtlasVars{0010 0100 0110 0120 1000 1100 1110 1120 1220} \\[2pt]
4h & 36 & \AtlasGroup{1}{0010 0011 0210 0211 1000 1100 1220 1222 1320 1322 1442 1542 2431 2432 2652 2653} & \AtlasVars{0001 0100 0110 0111 0220 0221 0222 1110 1111 1210 1211 1221 1321 1331 1332 1431 1432 2442 2542 2642} \\[2pt]
\end{longtable}
"""


def read_rows(path=None):
    """Read the three named TeX tables; reject unparsed columns or repeated labels."""
    tex = PRINTED_SUPPORT_TABLES if path is None else path.read_text(encoding="utf-8")
    rows = {}
    group = re.compile(r"\\AtlasGroup\{(\d+)\}\{([0-9 ]+)\}")
    table_row = re.compile(
        r"([234][a-z])\s*&\s*(\d+)\s*&\s*(.*?)\s*&\s*"
        r"\\AtlasVars\{([0-9 ]*)\}\s*\\\\(?:\[[^\]]*\])?\s*"
    )
    for r in (2, 3, 4):
        anchor = r"\label{tab:atlas" + str(r) + "}"
        require(tex.count(anchor) == 1, f"Missing or ambiguous table {anchor}")
        table, end, _ = tex.split(anchor, 1)[1].partition(r"\end{longtable}")
        require(end, f"Unterminated table {anchor}")
        for line in table.splitlines():
            if not re.match(r"\s*\d+[a-z]\s*&", line):
                continue
            match = table_row.fullmatch(line.strip())
            require(match, f"Malformed table row: {line}")
            name, count, fixed_column, variable_column = match.groups()
            require(int(name[0]) == r and name not in rows, f"Misplaced or duplicate row {name}")
            require(not group.sub("", fixed_column).strip(), f"{name}: unparsed fixed entry")
            fixed = {}
            for k, words in group.findall(fixed_column):
                require(int(k) > 0, f"{name}: nonpositive fixed entry")
                for word in words.split():
                    t = tuple(map(int, word))
                    require(t not in fixed, f"{name}: repeated fixed label {t}")
                    fixed[t] = int(k)
            variable = tuple(tuple(map(int, w)) for w in variable_column.split())
            row = Row(name, fixed, variable)
            support = row.support
            require(len(set(support)) == len(support) == int(count), f"{name}: column count")
            require(all(len(t) == r and any(t) for t in support), f"{name}: invalid vector")
            rows[name] = row
    require(set(rows) == set(ROW_NAMES), "Expected rows 2a–2h, 3a–3k and 4a–4h")
    return rows


def D(a, b):
    return z3.And(b >= 1, z3.Or(z3.And(a % 2 == 0, a >= 4, a <= 2*b + 2), a == 2*b + 3))


def T(a, b):
    return z3.Or(z3.And(a == 6, b == 3), z3.And(a == 7, b >= 4))


def repeated_min(a, b, c):
    return z3.Or(z3.And(a == b, a <= c), z3.And(b == c, b <= a), z3.And(c == a, c <= b))


def all_equal(values, k):
    return z3.And([v == k for v in values])


@cache
def cocircuits(rows, prime):
    """Supports of normals to the hyperplanes spanned by the label vectors.

    Project to pivot columns over the chosen field. This identifies the row
    span with its rank-dimensional coordinate space. Every spanned hyperplane
    has a basis of rank-1 labels; cofactors give its normal in these coordinates.
    """
    field = sp.GF(prime) if prime else sp.QQ
    _, pivots = sp.Matrix(rows).to_DM().convert_to(field).rref()
    rank = len(pivots)
    if rank == 0:
        return ()
    vectors = [tuple(v[j] for j in pivots) for v in rows]
    supports = set()
    for basis in combinations(sorted(set(vectors)), rank - 1):
        normal = []
        for j in range(rank):
            minor = sp.Matrix([v[:j] + v[j+1:] for v in basis])
            normal.append((-1)**j * int(minor.det()))
        values = [sum(a*b for a, b in zip(normal, v)) for v in vectors]
        nonzero = tuple(i for i, x in enumerate(values) if (x % prime if prime else x))
        if nonzero:
            supports.add(nonzero)
    return tuple(sorted(supports))


def contact(vectors, depths, residues=None, prime=0):
    """Printed span test, implemented independently of Cartan orbit-flat enumeration.

    An exiting label avoids the span of the deeper labels iff some spanned
    hyperplane contains all deeper labels and omits it. Extend a basis of the
    deeper span together with the target to a basis to see the reverse test.
    """
    def at_field(rows, p):
        require(len(rows) == len(depths), "Contact label/depth mismatch")
        tests = [[] for _ in rows]
        for support in cocircuits(tuple(rows), p):
            for i in support:
                tests[i].append(z3.And([depths[j] <= depths[i] for j in support if j != i]))
        return [z3.Or(alternatives) for alternatives in tests]

    tests = at_field(vectors, 0)
    if prime:
        modular = at_field(residues, prime)
        tests = [z3.If(d % prime == 0, q, f) for d, q, f in zip(depths, tests, modular)]
    return z3.And([d > 0 for d in depths] + tests)


def folded(vectors, values, kind):
    """F(I). Work in the lattice generated by the columns, including in lower rank."""
    columns = sp.Matrix(vectors).T
    lattice = hermite_normal_form(columns)
    coords = lattice.gauss_jordan_solve(columns)[0]
    require(all(x.is_Integer for x in coords), "Nonintegral root-lattice coordinates")
    metric = (coords * coords.T).inv()
    norms = [(v.T * metric * v)[0] for v in (coords[:, j] for j in range(coords.cols))]
    scales = sorted(set(norms))
    prime, short_count, long_count = {"B2": (2, 2, 2), "B3": (2, 3, 6),
                                      "C3": (2, 6, 3), "F4": (2, 12, 12), "G2": (3, 3, 3)}[kind]
    require(len(scales) == 2 and scales[1] == prime * scales[0]
            and norms.count(scales[0]) == short_count and norms.count(scales[1]) == long_count,
            f"Unexpected {kind} core lengths")
    roots = [tuple(map(int, coords[:, j])) for j in range(coords.cols)]
    long = [v for v, norm in zip(roots, norms) if norm == scales[1]]
    long_lattice = hermite_normal_form(sp.Matrix(long).T)
    require(all(v.is_Integer for v in prime * long_lattice.inv()),
            "The long-root quotient is not killed by the folding degree")

    # A class in Q / Z R_long is represented by its evaluations on the dual
    # of this F_p vector space. In particular all long roots map to zero.
    def dot(a, b):
        return sum(x*y for x, y in zip(a, b)) % prime

    dual = [a for a in product(range(prime), repeat=coords.rows)
            if all(dot(a, b) == 0 for b in long)]
    residues = [tuple(dot(a, b) for a in dual) for b in roots]
    depths = [v - (prime - 1) if norm == scales[0] else prime * v
              for v, norm in zip(values, norms)]
    short = [v for v, norm in zip(values, norms) if norm == scales[0]]
    return contact(roots, depths, residues, prime), short


def add(a, b, sign=1):
    return tuple(x + sign*y for x, y in zip(a, b))


def double(a):
    return tuple(2*x for x in a)


def partitions(items):
    if not items:
        yield ()
        return
    i, *rest = items
    for blocks in partitions(rest):
        yield ((i,),) + blocks
        for j, block in enumerate(blocks):
            yield blocks[:j] + ((i,) + block,) + blocks[j+1:]


def bc_axes(vectors):
    labels = set(vectors)
    axes = tuple(v for v in vectors if double(v) in labels)
    r = len(vectors[0])
    require(len(axes) == r and sp.Matrix(axes).rank() == r, "Invalid doubled directions")
    expected = set(axes) | {double(a) for a in axes}
    expected.update(sign_pair(add(a, b, sign))
                    for a, b in combinations(axes, 2) for sign in (-1, 1))
    require(expected == labels, "Variable columns differ from the full BC configuration")
    return axes


def allowed_activity(r, blocks, flags):
    active = [len(b) for b, on in zip(blocks, flags) if on]
    sizes = sorted(map(len, blocks))
    if r in (2, 3):                 # Theorem on canonical BC boundary factorisation
        return len(active) <= 2
    if sizes == [4]:
        return not active
    if sizes == [1, 3]:
        return 1 not in active
    if sizes == [2, 2]:
        return len(active) <= 1
    if sizes == [1, 1, 2]:
        return active.count(1) <= 1
    require(sizes == [1, 1, 1, 1], "Unknown BC4 partition")
    return len(active) <= 2


def bc_condition(vectors, xs):
    """3f uses class factorisation; 4h uses the capacity table in Appendix A."""
    axes = bc_axes(vectors)
    r = len(axes)
    values = dict(zip(vectors, xs))
    if r == 4:
        require(abs(sp.Matrix(axes).det()) == 1, "4h axes must give a basis of the printed Z^4")

    def pair(i, j, sign):
        return values[sign_pair(add(axes[i], axes[j], sign))]

    # All tests use coordinates in the primitive-axis basis of the model lattice.
    unit = [tuple(int(i == j) for j in range(r)) for i in range(r)]

    @cache
    def class_condition(block, active):
        forms = [double(unit[i]) for i in block]
        depths = [2 * values[double(axes[i])] for i in block]
        for i, j in combinations(block, 2):
            for sign in (-1, 1):
                forms.append(add(unit[i], unit[j], sign))
                depths.append(pair(i, j, sign) - 1)
        primitives = [values[axes[i]] for i in block]
        if active:
            forms.extend(unit[i] for i in block)
            depths.extend(a - 3 for a in primitives)
        flags = [a > 4 if active else a == 4 for a in primitives]
        return z3.And(*flags, contact(forms, depths, forms, 2))

    alternatives = []
    for blocks in partitions(range(r)):
        pairs = []
        for i, j in combinations(range(r), 2):
            inside = any(i in block and j in block for block in blocks)
            for sign in (-1, 1):
                v = pair(i, j, sign)
                pairs.append(v > 2 if inside else v == 2)
        cases = []
        for flags in product((False, True), repeat=len(blocks)):
            if allowed_activity(r, blocks, flags):
                cases.append(z3.And([class_condition(b, on) for b, on in zip(blocks, flags)]))
        alternatives.append(z3.And(*pairs, z3.Or(cases)))
    return z3.Or(alternatives)


def two_e(xs):
    P, A, R, Q, S, Dprime = xs

    def in_L(v, b):
        return z3.Or(v == 6, z3.And(v % 2 == 0, 8 <= v, v <= 2*b + 2), v == 2*b + 3)

    a, d, u, v = 2*A - 2, 2*Dprime - 2, R - 3, S - 3
    depths = [a, d, u, v]
    h = a
    for x in depths[1:]:
        h = z3.If(x < h, x, h)
    mixed = z3.If(h % 2 == 0, z3.Sum([z3.If(x == h, 1, 0) for x in depths]) >= 3,
                  z3.And(u == h, v == h, h < a, h < d))
    return z3.And(A >= 2, Dprime >= 2, z3.Or(
        z3.And(Q == 6, R == 4, S == 4, in_L(P, A)),
        z3.And(P == 6, R == 4, S == 4, in_L(Q, Dprime)),
        z3.And(P == 6, Q == 6, R >= 5, S >= 5, mixed)))


def printed_rule(name, vectors, xs):
    """Each x[i] denotes the value on the i-th right-column vector (i starts at 1)."""
    x = [None, *xs]
    star = set(range(1, len(x)))

    def F(indices, kind):
        indices = sorted(indices)
        return folded([vectors[i-1] for i in indices], [x[i] for i in indices], kind)

    if name in ("2a", "2b", "2d"):
        return z3.BoolVal(True)     # Fixed columns and positivity are imposed separately.
    if name == "2c":
        return z3.And(T(x[1], x[2]), x[3] >= 3, z3.Or(x[2] == 3, x[3] == 3))
    if name == "2e":
        return two_e(xs)
    if name == "2f":
        return x[1] >= 2
    if name == "2g":
        return D(x[1], x[2])
    if name == "2h":
        return z3.And(T(x[1], x[2]), T(x[3], x[4]), z3.Or(x[1] == 6, x[3] == 6))
    if name in ("3a", "3k"):
        b, tri = (3, (2, 4, 5)) if name == "3a" else (2, (3, 4, 5))
        t = [x[i] for i in tri]
        return z3.And(D(x[1], x[b]), *[v >= 2 for v in t], repeated_min(*t),
                      z3.Or([x[1] == 4] + [v == 2 for v in t]))
    if name == "3b":
        return z3.And(D(x[1], x[3]), x[2] >= 2, z3.Or(x[1] == 4, x[2] == 2))
    if name == "3c":
        f, short = F(star - {1}, "G2")
        return z3.And(f, x[1] >= 3, z3.Or(x[1] == 3, all_equal(short, 3)))
    if name == "3d":
        return z3.And(x[1] >= 2, x[2] >= 1)
    if name == "3e":
        return z3.And(D(x[5], x[8]), F(star - {5, 8}, "G2")[0])
    if name in ("3f", "4h"):
        return bc_condition(vectors, xs)
    if name == "3g":
        return repeated_min(*xs)
    if name in ("3h", "4a", "4g"):
        return F(star, "B2" if name == "3h" else "B3")[0]
    if name == "3i":
        u, v, w = (1, 0, 1), (1, 1, 1), (2, 1, 1)
        forms = [u, double(u), v, double(v), w, add(u, v), add(u, v, -1)]
        depths = [x[2]-3, 2*x[4], x[3]-3, 2*x[6], x[7]-1, x[5]-1, x[1]-1]
        return z3.And(contact(forms, depths, forms, 2),
                      z3.Implies(x[7] > 2, z3.And(x[2] == 4, x[3] == 4)))
    if name == "3j":
        f, short = F(star - {2, 3}, "G2")
        return z3.And(T(x[2], x[3]), f, z3.Implies(x[3] > 3, all_equal(short, 3)))
    if name == "4b":
        return F(star - {10}, "B3")[0]
    if name == "4c":
        return contact(vectors, xs)
    if name == "4d":
        f, short = F(star - {4, 6}, "C3")
        return z3.And(D(x[4], x[6]), f, z3.Or([x[4] == 4] + [v == 2 for v in short]))
    if name == "4e":
        f, short = F(star - {2, 5}, "B3")
        return z3.And(D(x[2], x[5]), f, z3.Or(x[2] == 4, all_equal(short, 2)))
    if name == "4f":
        f, short_i = F({1, 5, 6, 8, 9, 12}, "G2")
        g, short_j = F({2, 3, 4, 7, 10, 11}, "G2")
        return z3.And(f, g, z3.Or(all_equal(short_i, 3), all_equal(short_j, 3)))
    raise ValueError(f"No indexed condition for row {name}")
