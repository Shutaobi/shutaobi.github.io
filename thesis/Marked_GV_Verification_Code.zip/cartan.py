"""Exact exceptional root orders for Sections 2.3.2–2.3.3 of the manuscript.

An orbit index represents all its roots throughout. A prefix records the first
nonzero degree of each orbit, with 0 for an orbit that survives the prefix.
The only quotient taken on prefixes is by the individual component Coxeters.
"""

from collections import defaultdict
from functools import cache, lru_cache
from itertools import chain
from math import gcd, lcm

import sympy as sp
import z3


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sign_pair(v):
    """A consistent representative of {v, -v}, including mixed-sign vectors."""
    v = tuple(v)
    if next((x for x in v if x), 0) < 0:
        return tuple(-x for x in v)
    return v


@cache
def root_system(n):
    """Chain 1,...,n-1 with n attached to 3 (zero-based internally)."""
    edges = [(i, i + 1) for i in range(n - 2)] + [(2, n - 1)]
    gram = 2 * sp.eye(n)
    neighbors = [set() for _ in range(n)]
    for i, j in edges:
        gram[i, j] = gram[j, i] = -1
        neighbors[i].add(j)
        neighbors[j].add(i)

    simple = [tuple(int(i == j) for j in range(n)) for i in range(n)]
    seen = set(simple)
    pending = list(simple)
    while pending:
        a = pending.pop()
        for i in range(n):
            b = list(a)
            b[i] = sum(a[j] for j in neighbors[i]) - a[i]
            b = tuple(b)
            if b not in seen:
                seen.add(b)
                pending.append(b)
    roots = tuple(sorted(a for a in seen if min(a) >= 0))
    require(len(seen) == 2 * len(roots) and len(roots) == {6: 36, 7: 63, 8: 120}[n],
            f"E{n}: root census failed")
    reflections = []
    for i in range(n):
        reflection = sp.eye(n)
        reflection[i, :] -= gram[i, :]
        reflections.append(reflection)
    return roots, neighbors, reflections, sp.Matrix(roots) * gram


def projection(a, visible):
    return tuple(a[j] for j in visible)


def projected_support(roots, visible):
    labels = {projection(a, visible) for a in roots}
    labels.discard((0,) * len(visible))
    return tuple(sorted(labels))


def normalize(v):
    """Primitive integer representative with first nonzero entry positive."""
    pivot = next((x for x in v if x), 0)
    if not pivot:
        return v
    divisor = gcd(*v) * (1 if pivot > 0 else -1)
    return tuple(x // divisor for x in v)


@lru_cache(maxsize=65536)
def adjoin(space, row):
    """Insert one row into a primitive integral echelon basis over Q."""
    row = normalize(row)
    for b in space:
        j = next(i for i, x in enumerate(b) if x)
        if row[j]:
            row = normalize(tuple(b[j] * x - row[j] * y for x, y in zip(row, b)))
    if not any(row):
        return space
    j = next(i for i, x in enumerate(row) if x)
    basis = [row]
    for b in space:
        if b[j]:
            b = normalize(tuple(row[j] * x - b[j] * y for x, y in zip(b, row)))
        basis.append(b)
    return tuple(sorted(basis, key=lambda v: next(i for i, x in enumerate(v) if x)))


def extend(space, rows):
    for row in rows:
        space = adjoin(space, row)
    return space


def flats(groups, vanish=(), exit_now=()):
    """All flats of whole groups, with the indicated vanishing and exit conditions."""
    start = extend((), chain.from_iterable(groups[i] for i in vanish))
    pending = [start]
    seen = {start}
    while pending:
        space = pending.pop()
        enlarged = [extend(space, group) for group in groups]
        closed = frozenset(i for i, new in enumerate(enlarged) if new == space)
        if closed.intersection(exit_now):
            continue
        yield closed
        for i, new in enumerate(enlarged):
            if i not in exit_now and new not in seen:
                seen.add(new)
                pending.append(new)


@lru_cache(maxsize=4096)
def separating_complements(groups):
    """For each target take complements of the maximal flats avoiding it."""
    closed = list(flats(groups))
    universe = frozenset(range(len(groups)))
    answers = []
    for i in range(len(groups)):
        candidates = sorted((universe - flat - {i} for flat in closed if i not in flat),
                            key=lambda s: (len(s), sorted(s)))
        minimal = []
        for other in candidates:
            if not any(used <= other for used in minimal):
                minimal.append(other)
        answers.append(tuple(tuple(sorted(other)) for other in minimal))
    return answers


def exit_tests(groups, depths):
    """The strict superlevel set must lie in a flat avoiding the exiting group."""
    tests = []
    for i, alternatives in enumerate(separating_complements(tuple(groups))):
        if () in alternatives:
            test = z3.BoolVal(True)
        else:
            test = z3.Or([z3.And([depths[j] <= depths[i] for j in other])
                          for other in alternatives])
        tests.append(test)
    return tests


def components(internal, neighbors):
    remaining = set(internal)
    while remaining:
        first = min(remaining)
        component = {first}
        pending = [first]
        while pending:
            new = (neighbors[pending.pop()] & remaining) - component
            component.update(new)
            pending.extend(new)
        remaining -= component
        yield sorted(component)


def cycles(permutation):
    require(set(permutation) == set(range(len(permutation))), "Invalid permutation")
    seen = set()
    for i in range(len(permutation)):
        if i in seen:
            continue
        orbit = []
        while i not in seen:
            seen.add(i)
            orbit.append(i)
            i = permutation[i]
        yield tuple(orbit)


def component_action(n, nodes, reflections, roots):
    matrix = sp.eye(n)
    for i in nodes:
        matrix = matrix * reflections[i]
    # Compute h on the full roots: a sign flip may shorten an orbit on pairs.
    images = [tuple(map(int, v)) for v in (sp.Matrix(roots) * matrix.T).tolist()]
    signed_roots = roots + tuple(tuple(-x for x in a) for a in roots)
    index = {a: j for j, a in enumerate(signed_roots)}
    positive_images = [index[a] for a in images]
    size = len(roots)
    signed_perm = positive_images + [(j + size) % (2 * size) for j in positive_images]
    h = lcm(*(len(orbit) for orbit in cycles(signed_perm)))
    return matrix, h, tuple(j % size for j in positive_images)


def character_groups(matrix, d, normals, orbits):
    """Restrict root forms to ker Phi_d(c) and span the restrictions in each orbit."""
    t = sp.Symbol("t")
    poly = sp.Poly(sp.cyclotomic_poly(d, t), t)
    value = sp.zeros(matrix.rows)
    eye = sp.eye(matrix.rows)
    for coefficient in poly.all_coeffs():
        value = value * matrix + coefficient * eye
    columns = value.nullspace()
    if not columns:
        return tuple(() for _ in orbits)
    # Clear denominators per basis column. This is one common coordinate change.
    columns = [v * lcm(*(int(x.q) for x in v)) for v in columns]
    evaluations = normals * sp.Matrix.hstack(*columns)
    rows = [tuple(map(int, v)) for v in evaluations.tolist()]
    return tuple(extend((), (rows[j] for j in orbit)) for orbit in orbits)


def initial_patterns(m, limit, prescribed, characters):
    """Adjoin exact vanishing flats up to the last prescribed internal degree."""
    initial = (0,) * len(prescribed)
    states = {initial}
    for k in range(1, limit + 1):
        groups = characters[m // gcd(m, k)]
        next_states = set()
        for state in sorted(states):
            live = [i for i, value in enumerate(state) if value == 0]
            vanish = [j for j, i in enumerate(live) if prescribed[i] > k]
            exits = {j for j, i in enumerate(live) if prescribed[i] == k}
            for zeros in flats([groups[i] for i in live], vanish=vanish, exit_now=exits):
                new = list(state)
                for j, i in enumerate(live):
                    if j not in zeros:
                        new[i] = k
                next_states.add(tuple(new))
        states = next_states
    require(states, "No admissible smooth initial pattern")
    return states


def representatives(states, actions):
    """Take one state per orbit of the commuting component Coxeters."""
    remaining = set(states)
    while remaining:
        state = min(remaining)
        yield state
        pending = [state]
        remaining.remove(state)
        while pending:
            a = pending.pop()
            for perm in actions:
                b = tuple(a[i] for i in perm)
                require(b in states, "Component action lost a smooth initial pattern")
                if b in remaining:
                    remaining.remove(b)
                    pending.append(b)


def tail_formula(state, fibres, sizes, numbers, m, limit, characters):
    conditions, depths, surviving = [], [], []
    for label, indices in fibres.items():
        total = sum(sizes[i] * state[i] for i in indices)
        require(total % m == 0, f"Nonintegral prefix sum on {label}")
        base = total // m
        live = [i for i in indices if state[i] == 0]
        if not live:
            conditions.append(numbers[label] == base)
            continue
        require(len(live) == 1, f"More than one surviving orbit on {label}")
        i, = live
        require(m % sizes[i] == 0, "Orbit size must divide the cover degree")
        depth = (m // sizes[i]) * (numbers[label] - base)
        depths.append(depth)
        surviving.append(i)
        conditions.append(depth > limit)
    for d, groups in characters.items():
        tests = exit_tests([groups[i] for i in surviving], depths)
        residues = [k for k in range(m) if m // gcd(m, k) == d]
        for depth, test in zip(depths, tests):
            if not z3.is_true(test):
                at_character = z3.Or([depth % m == k for k in residues])
                conditions.append(z3.Implies(at_character, test))
    return z3.simplify(z3.And(conditions))


def cartan_image(n, visible, numbers):
    """Return a list of prefix predicates in the supplied, labelled integer variables."""
    roots, neighbors, reflections, normals = root_system(n)
    internal = set(range(n)) - set(visible)
    parts = list(components(internal, neighbors))
    require(parts, "The low-rank atlas requires nonempty internal nodes")
    actions = [component_action(n, part, reflections, roots) for part in parts]
    m = lcm(*(h for matrix, h, perm in actions))
    limit = max(m // h for matrix, h, perm in actions)
    required_at = {j: m // h for part, (_, h, _) in zip(parts, actions) for j in part}

    c = sp.eye(n)
    perm = tuple(range(len(roots)))
    for matrix, _, action in actions:
        c = c * matrix
        perm = tuple(perm[i] for i in action)
    orbits = tuple(cycles(perm))
    orbit_of = {j: i for i, orbit in enumerate(orbits) for j in orbit}

    fibres = defaultdict(list)
    prescribed = [0] * len(orbits)
    for i, orbit in enumerate(orbits):
        labels = {projection(roots[j], visible) for j in orbit}
        require(len(labels) == 1, "Coxeter action changed a projected sign-pair")
        label, = labels
        if any(label):
            fibres[label].append(i)
        else:
            orders = {required_at[k] for j in orbit for k, x in enumerate(roots[j]) if x}
            require(len(orders) == 1, "An internal orbit crossed component orders")
            prescribed[i], = orders
    require(set(fibres) == set(numbers), "Cartan label set differs from transported row")

    characters = {d: character_groups(c, d, normals, orbits)
                  for d in range(1, m + 1) if m % d == 0}
    states = initial_patterns(m, limit, prescribed, characters)
    orbit_actions = []
    for matrix, _, action in actions:
        require(matrix*c == c*matrix, "Component Coxeter does not commute with the product")
        require(all(projection(a, visible) == projection(roots[action[j]], visible)
                    for j, a in enumerate(roots)), "Component action changed a projected label")
        induced = []
        for orbit in orbits:
            images = {orbit_of[action[j]] for j in orbit}
            require(len(images) == 1, "Component action failed to preserve Coxeter orbits")
            induced.append(images.pop())
        orbit_actions.append(induced)
    sizes = list(map(len, orbits))
    return [tail_formula(state, fibres, sizes, numbers, m, limit, characters)
            for state in representatives(states, orbit_actions)]
