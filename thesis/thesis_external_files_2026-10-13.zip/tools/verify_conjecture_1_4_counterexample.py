#!/usr/bin/env python3
"""Exact verification for the D_{2,2} smooth-centre counterexample.

Python 3.10+; standard library only. All row reduction is over Q, using Fraction.
Run: python3 verify_conjecture_1_4_counterexample.py

A = Q<x,y>/(xy+yx, y^2+x^2+x^3, x^5).
A basis: (1,x,x^2,x^3,x^4,y,xy,x^2y).
C = Z(A) has basis (1,u,v,w,q), embedded as (1,x^2,x^3,x^2y,x^4).
Its only nonzero radical product is u*u=q.
The polynomial centre deformation changes v*v from 0 to t*w.

The mathematical nonlifting proof uses X^5=epsilon*b in a hypothetical
flat lift: [b mod epsilon,x]=0 forces the square of any lift of x^3 to
have no epsilon*x^2y coefficient. It cannot equal epsilon times a lift
of x^2y. The checks below independently verify the multiplication tables,
all normalized Hochschild ranks, the induced centre differential, and the
explicit tangent direction excluded from its image.
"""
from __future__ import annotations

from fractions import Fraction as F
from itertools import product
from typing import Iterable

Vector = dict[int, F | int]
Table = dict[tuple[int, int], Vector]
Coordinates = dict[tuple[int, int, int], int]


def add_term(row: dict, key, value) -> None:
    if value:
        total = row.get(key, 0) + value
        if total:
            row[key] = total
        else:
            row.pop(key, None)


def echelon(rows: Iterable[Vector]) -> dict[int, dict[int, F]]:
    """Normalized sparse row-echelon basis, with exact rational pivots."""
    pivots: dict[int, dict[int, F]] = {}
    for original in rows:
        row = {i: F(v) for i, v in original.items() if v}
        while row:
            j = min(row)
            if j not in pivots:
                leading = row[j]
                pivots[j] = {i: v / leading for i, v in row.items()}
                break
            factor = row[j]
            for i, value in pivots[j].items():
                add_term(row, i, -factor * value)
    return pivots


def rank(rows: Iterable[Vector]) -> int:
    return len(echelon(rows))


def nullspace(pivots: dict[int, dict[int, F]], ncols: int) -> list[Vector]:
    result = []
    for free in sorted(set(range(ncols)) - set(pivots)):
        vector: Vector = {free: F(1)}
        for j in sorted(pivots, reverse=True):
            value = -sum(v * vector.get(i, 0)
                         for i, v in pivots[j].items() if i != j)
            if value:
                vector[j] = value
        result.append(vector)
    return result


def pairing(row: Vector, vector: Vector):
    return sum(value * vector.get(i, 0) for i, value in row.items())


def multiply(table: Table, left: Vector, right: Vector) -> Vector:
    out: Vector = {}
    for i, a in left.items():
        for j, b in right.items():
            for k, value in table[i, j].items():
                add_term(out, k, a * b * value)
    return out


def verify_associativity(table: Table, dimension: int) -> None:
    for i in range(dimension):
        assert table[0, i] == table[i, 0] == {i: 1}
    for i, j, k in product(range(dimension), repeat=3):
        assert multiply(table, table[i, j], {k: 1}) == \
               multiply(table, {i: 1}, table[j, k])


def algebra_D_n2(n: int) -> tuple[Table, list[tuple[int, int]]]:
    if n < 2:
        raise ValueError('n must be at least 2')
    basis = [(i, 0) for i in range(2*n + 1)] + \
            [(i, 1) for i in range(2*n - 1)]
    indices = {word: i for i, word in enumerate(basis)}
    table: Table = {}
    for i, (a, b) in enumerate(basis):
        for j, (c, e) in enumerate(basis):
            sign = (-1) ** (b*c)
            if b + e < 2:
                terms = {(a+c, b+e): sign}
            else:
                terms = {(a+c+2, 0): -sign,
                         (a+c+2*n-1, 0): -sign}
            table[i, j] = {indices[word]: value for word, value in terms.items()
                           if word in indices and value}
    return table, basis


def centre_table() -> Table:
    # Basis: 1,u,v,w,q. The radical has only u*u=q nonzero.
    table: Table = {(i, j): {} for i, j in product(range(5), repeat=2)}
    for i in range(5):
        table[0, i] = table[i, 0] = {i: 1}
    table[1, 1] = {4: 1}
    return table


def differential_two(table: Table, d: int, symmetric: bool = False
                     ) -> tuple[list[Vector], Coordinates]:
    pairs = [(i, j) for i in range(1, d)
             for j in range(i if symmetric else 1, d)]
    coords = {(i, j, k): q for q, (i, j, k) in
              enumerate((i, j, k) for i, j in pairs for k in range(d))}

    def coordinate(i: int, j: int, k: int):
        if not i or not j:
            return None
        if symmetric and j < i:
            i, j = j, i
        return coords[i, j, k]

    rows: list[Vector] = []
    for a, b, c, k in product(range(1, d), range(1, d), range(1, d), range(d)):
        row: Vector = {}

        def put(index, value):
            if index is not None:
                add_term(row, index, value)

        # delta(phi)(a,b,c) = a phi(b,c) - phi(ab,c)
        #                    + phi(a,bc) - phi(a,b)c.
        for x in range(d):
            put(coordinate(b, c, x), table[a, x].get(k, 0))
            put(coordinate(a, b, x), -table[x, c].get(k, 0))
        for x, value in table[a, b].items():
            put(coordinate(x, c, k), -value)
        for x, value in table[b, c].items():
            put(coordinate(a, x, k), value)
        if row:
            rows.append(row)
    return rows, coords


def coboundaries(table: Table, d: int, coords: Coordinates) -> list[Vector]:
    """Columns of delta:C^1_norm -> C^2_norm (symmetric if coords are)."""
    result: list[Vector] = []
    for a in range(1, d):
        for k in range(d):
            out: Vector = {}
            # f(e_a)=e_k, and f vanishes on the other basis elements.
            for (i, j, b), coordinate in coords.items():
                value = (table[i, k].get(b, 0) if j == a else 0)
                value += (table[k, j].get(b, 0) if i == a else 0)
                value -= (table[i, j].get(a, 0) if b == k else 0)
                if value:
                    out[coordinate] = value
            result.append(out)
    return result


def commutator_equations(table: Table, d: int,
                        test_elements: Iterable[int]) -> list[Vector]:
    return [{i: value for i in range(d)
             if (value := table[i, a].get(k, 0) - table[a, i].get(k, 0))}
            for a in test_elements for k in range(d)]


def verify_polynomial_centre_family() -> None:
    """Verify the multiplication over Q[t], without truncating t."""
    # A polynomial-valued vector uses keys (basis_index, t_exponent).
    base = centre_table()
    table = {(i, j): {(k, 0): value for k, value in output.items()}
             for (i, j), output in base.items()}
    table[2, 2] = {(3, 1): 1}  # v*v=t*w.
    for i, j, k in product(range(5), repeat=3):
        left, right = {}, {}
        for (a, exponent), value in table[i, j].items():
            for (b, exponent2), value2 in table[a, k].items():
                add_term(left, (b, exponent + exponent2), value * value2)
        for (a, exponent), value in table[j, k].items():
            for (b, exponent2), value2 in table[i, a].items():
                add_term(right, (b, exponent + exponent2), value * value2)
        assert left == right


def induced_centre_cocycle(phi: Vector, A: Table, C: Table,
                          ac: Coordinates, cc: Coordinates) -> Vector:
    """Lift the centre in the first-order algebra and read its product.

    The central basis is corrected in the complement span(x,y,xy), so
    tau_1=0 and tau_u,tau_v,tau_w,tau_q have three coefficients each.
    Solve [tau_i,a] + phi(c_i,a) - phi(a,c_i) = 0 over Q.
    """
    embedding = [0, 2, 3, 7, 4]
    centre_indices = {value: index for index, value in enumerate(embedding)}
    complement = [1, 5, 6]

    def p(i, j, k):
        return phi.get(ac[i, j, k], 0) if i and j else 0

    equations = []
    for i in range(1, 5):
        for a in range(1, 8):
            for k in range(8):
                row: Vector = {}
                for z, basis_index in enumerate(complement):
                    add_term(row, 3*(i-1)+z,
                             A[basis_index, a].get(k, 0) -
                             A[a, basis_index].get(k, 0))
                add_term(row, 12, p(embedding[i], a, k)-p(a, embedding[i], k))
                equations.append(row)
    pivots = echelon(equations)
    assert 12 not in pivots, 'A centre element fails to lift'
    assert len(pivots) == 12, 'Complement did not give unique lifts'
    solution: Vector = {12: F(1)}
    for j in sorted(pivots, reverse=True):
        solution[j] = -sum(value * solution.get(k, 0)
                           for k, value in pivots[j].items() if k != j)
    tau = {i: {z: solution[3*(i-1)+t]
               for t, z in enumerate(complement)} for i in range(1, 5)}
    tau[0] = {}

    def product_correction(i, j) -> Vector:
        output: Vector = {}
        for k in range(8):
            value = p(embedding[i], embedding[j], k)
            value += sum(t * A[z, embedding[j]].get(k, 0)
                         for z, t in tau[i].items())
            value += sum(t * A[embedding[i], z].get(k, 0)
                         for z, t in tau[j].items())
            value -= sum(t * tau[r].get(k, 0) for r, t in C[i, j].items())
            if value:
                assert k in centre_indices
                output[centre_indices[k]] = value
        return output

    answer: Vector = {}
    for i in range(1, 5):
        for j in range(i, 5):
            output = product_correction(i, j)
            assert output == product_correction(j, i)
            for k, value in output.items():
                answer[cc[i, j, k]] = value
    return answer


def main() -> None:
    A, _ = algebra_D_n2(2)
    C = centre_table()
    verify_associativity(A, 8)
    verify_associativity(C, 5)
    verify_polynomial_centre_family()

    # Independently check the centre and its embedded multiplication table.
    embedding = [0, 2, 3, 7, 4]
    assert 8-rank(commutator_equations(A, 8, range(8))) == 5
    assert 8-rank(commutator_equations(A, 8, [1])) == 6
    for i, j in product(range(5), repeat=2):
        assert A[embedding[i], embedding[j]] == \
               {embedding[k]: v for k, v in C[i, j].items()}

    ar, ac = differential_two(A, 8)
    cr, cc = differential_two(C, 5, symmetric=True)
    ab, cb = coboundaries(A, 8, ac), coboundaries(C, 5, cc)
    ap, cp = echelon(ar), echelon(cr)
    ak = nullspace(ap, len(ac))
    assert all(pairing(row, vector) == 0 for row in ar for vector in ab)
    assert all(pairing(row, vector) == 0 for row in cr for vector in cb)
    assert all(pairing(row, vector) == 0 for row in ar for vector in ak)

    a_d1, a_d2 = rank(ab), len(ap)
    c_d1, c_d2 = rank(cb), len(cp)
    a_z2, c_z2 = len(ac)-a_d2, len(cc)-c_d2
    a_hh2, c_t1 = a_z2-a_d1, c_z2-c_d1
    a_der, c_der = 8*7-a_d1, 5*4-c_d1
    a_hh1 = a_der-(8-5)
    assert (a_d1, a_d2, a_z2, a_der, a_hh1, a_hh2) == (50,339,53,6,3,3)
    assert (c_d1, c_d2, c_z2, c_der, c_t1) == (10,24,26,10,16)

    centre_images = [induced_centre_cocycle(phi, A, C, ac, cc) for phi in ak]
    assert all(pairing(row, psi) == 0 for row in cr for psi in centre_images)
    image_rank_mod_boundaries = rank(cb+centre_images)-rank(cb)
    assert image_rank_mod_boundaries == 3
    # Coboundaries in the source become coboundaries in the target.
    images_of_ab = [induced_centre_cocycle(phi, A, C, ac, cc) for phi in ab]
    assert rank(cb+images_of_ab) == rank(cb)

    witness: Vector = {cc[2, 2, 3]: 1}  # psi(v,v)=w.
    assert all(pairing(row, witness) == 0 for row in cr)
    assert all(vector.get(cc[2,2,3], 0) == 0 for vector in cb+centre_images)
    assert rank(cb+centre_images+[witness]) == rank(cb+centre_images)+1

    # Finite sanity checks of the identities used in the all-n proof.
    # These do not replace the uniform symbolic proof in the accompanying answer.
    for n in range(2, 7):
        T, basis = algebra_D_n2(n)
        d = len(basis)
        verify_associativity(T, d)
        indices = {word: i for i, word in enumerate(basis)}
        v, w = indices[2*n-1,0], indices[2*n-2,1]
        pure = set(range(2*n+1))
        assert d == 4*n
        assert d-rank(commutator_equations(T,d,range(d))) == n+3
        assert d-rank(commutator_equations(T,d,[1])) == 2*n+2
        assert T[1,w] == T[w,1] == {}
        assert all(set(T[v,i]) <= pure and set(T[i,v]) <= pure
                   for i in range(d))

    print('Exact verification over Q (Python fractions.Fraction)')
    print('No floating-point arithmetic or modular rank inference is used.')
    print('')
    print('A = D_{2,2}; basis = (1,x,x^2,x^3,x^4,y,xy,x^2y)')
    print('  Associativity and unit: PASS')
    print('  dim A = 8; dim Z(A) = 5; dim centralizer_A(x) = 6')
    print(f'  dim C^1_norm = 56; rank delta_1 = {a_d1}; dim Der(A) = {a_der}')
    print(f'  dim C^2_norm = 392; rank delta_2 = {a_d2}; dim Z^2_norm = {a_z2}')
    print(f'  dim HH^1(A) = {a_hh1}; dim HH^2(A) = {a_hh2}')
    print('')
    print('C = Z(A); basis = (1,u,v,w,q), with u^2=q')
    print('  Embedded centre multiplication table: PASS')
    print(f'  dim C^1_norm = 20; rank delta_1 = {c_d1}; dim Der(C) = {c_der}')
    print(f'  dim symmetric C^2_norm = 50; rank restricted delta_2 = {c_d2}')
    print(f'  dim symmetric Z^2_norm = {c_z2}; dim T^1_comm(C) = {c_t1}')
    print('')
    print('Centre differential:')
    print('  Every source cocycle admits central basis lifts: PASS')
    print('  Source coboundaries map to target coboundaries: PASS')
    print(f'  Rank on deformation-class tangent spaces = {image_rank_mod_boundaries}')
    print(f'  Tangent cokernel dimension = {c_t1-image_rank_mod_boundaries}')
    print('  Functional [psi] -> coefficient of w in psi(v,v) kills the image: PASS')
    print('  Explicit witness psi(v,v)=w has functional value 1: PASS')
    print('  Polynomial family v^2=t*w is associative over Q[t]: PASS')
    print('')
    print('Uniform-family identity sanity checks for D_{n,2}, n=2,...,6: PASS')
    print('ALL CHECKS PASSED')


if __name__ == '__main__':
    main()
