#!/usr/bin/env python3
"""Verify the thesis computations using only files in this directory tree."""
from __future__ import annotations
import argparse, contextlib, io, json, runpy, subprocess, sys
from collections import deque
from fractions import Fraction
from pathlib import Path

THESIS=Path(__file__).resolve().parents[1]
OUT=THESIS/'build'/'verification'
TOOLS=THESIS/'tools'
sys.dont_write_bytecode=True
# Appendix B.2: (degree, columns, rank) for the relations P, R4, R5 of Lemma B.3.
E8_TABLE=[(0,1,0),(1,2,0),(2,4,0),(3,6,0),(4,9,2),(5,12,5),(6,17,10),(7,22,16),
          (8,30,24),(9,40,34),(10,55,49),(11,74,69),(12,105,100),(13,146,142),
          (14,210,206),(15,304,300),(16,447,443),(17,658,655),(18,987,984),
          (19,1480,1478),(20,2246,2244),(21,3416,3414),(22,5227,5225),(23,8014,8013)]

def root_orbits():
    cases=[('A1',1,[],0,[1]),('D4',4,[(0,1),(1,2),(1,3)],1,[8,1])]
    for rank,mark,expect in [(6,2,[18,9,2]),(7,2,[24,18,8,3]),(8,3,[40,30,20,10,4]),(8,2,[30,30,20,15,6,5])]:
        edges=[(i,i+1) for i in range(rank-2)]+[(2,rank-1)]
        cases.append((f'E{rank}-mark{len(expect)}',rank,edges,mark,expect))
    result=[]
    for name,n,edges,p,expect in cases:
        adj=[[] for _ in range(n)]
        for a,b in edges:adj[a].append(b);adj[b].append(a)
        def reflect(v,i):
            u=list(v);u[i]=-v[i]+sum(v[h] for h in adj[i]);return tuple(u)
        roots={tuple(int(i==j) for i in range(n)) for j in range(n)}
        queue=deque(roots)
        while queue:
            v=queue.popleft()
            assert sum(2*x*x for x in v)-sum(2*v[a]*v[b] for a,b in edges)==2
            for i in range(n):
                u=reflect(v,i)
                if u not in roots:roots.add(u);queue.append(u)
        positive={v for v in roots if all(x>=0 for x in v)}
        sizes=[]
        for j in range(1,len(expect)+1):
            part={v for v in positive if v[p]==j};seed=next(iter(part));orbit={seed};queue=deque([seed])
            while queue:
                v=queue.popleft()
                for i in range(n):
                    if i==p:continue
                    u=reflect(v,i)
                    if u not in orbit:orbit.add(u);queue.append(u)
            assert orbit==part,(name,j)
            sizes.append(len(part))
        assert sizes==expect,(name,sizes)
        assert max(v[p] for v in positive)==len(expect)
        result.append({'case':name,'positive_roots':len(positive),'coefficient_orbits':sizes,'N_p':sum(sizes)})
    return result

def arithmetic():
    a=Fraction(-17043521,16777216);b=Fraction(266305,16777216)
    assert 1+a+b==0 and 1+a*64**4+b*64**5==0
    # e=1 mod X^4; e=0 at the two nonzero roots. CRT proves idempotence modulo the minimal polynomial.
    bounds=[1,2,4,6,7,7,7,6,6,6,6,5,5,4,4,4,4,3,3,2,2,2,2,1]
    assert sum(bounds)==99 and sum(bounds)+5==104
    n=[6,3,1];d=sum((j+1)**2*x for j,x in enumerate(n));z=sum(n)
    assert (d,z,d*(d-1)-d+z)==(27,10,685)
    # 13 simple factors and dimension 30 determine the global block sizes.
    solutions=[]
    for m2 in range(6):
        for m3 in range(3):
            for m4 in range(2):
                if 3*m2+8*m3+15*m4==17 and m2+m3+m4<=13:solutions.append((13-m2-m3-m4,m2,m3,m4))
    assert solutions==[(9,3,1,0)]
    return {'ce6_dimension':d,'ce6_centre':z,'ce6_tangent':685,'global_block_multiplicities':solutions[0],'E8_degrees_0_to_23_upper_bound':99,'E8_tail_upper_bound':5,'projector_interpolation':'passed'}

def run_tool(name):
    """Run a checker from tools/ and keep its output in build/verification."""
    buffer=io.StringIO();saved=sys.path[:]
    sys.path.insert(0,str(TOOLS))
    try:
        with contextlib.redirect_stdout(buffer):runpy.run_path(str(TOOLS/name),run_name='__main__')
    finally:sys.path[:]=saved
    text=buffer.getvalue();(OUT/(Path(name).stem+'.txt')).write_text(text)
    assert 'ALL CHECKS PASSED' in text,(name,text)
    return 'passed'

def section5_checks():
    """Lemma B.3 over Z[z]; Proposition 5.19 and Appendix C over Q."""
    return {'e8_rho_relations_over_Zz':run_tool('check_e8_rho_relations_formal.py'),
            'd22_counterexample_over_Q':run_tool('verify_conjecture_1_4_counterexample.py'),
            'd22_tangent_image_over_Q':run_tool('check_d22_tangent_image.py')}

def e8_ranks():
    """Appendix B.2: compile the rank checker and compare both primes with the table."""
    source=(TOOLS/'check_e8_corrected_rho.cpp').read_text();result={}
    for prime in (1000003,1000033):
        text=source.replace('MOD=1000003',f'MOD={prime}').replace('field=F_1000003',f'field=F_{prime}')
        assert f'MOD={prime};' in text
        cpp=OUT/f'e8_rank_{prime}.cpp';binary=OUT/f'e8_rank_{prime}.bin';cpp.write_text(text)
        subprocess.run(['c++','-O3','-std=c++17',str(cpp),'-o',str(binary)],check=True,capture_output=True)
        output=subprocess.run([str(binary),'23'],check=True,capture_output=True,text=True).stdout
        (OUT/f'e8_rank_{prime}.txt').write_text(output)
        rows=[tuple(int(x) for x in line.split()[:3]) for line in output.splitlines() if line[:1].isdigit()]
        assert rows==E8_TABLE,(prime,rows)
        assert sum(c-r for _,c,r in rows)==99
        result[f'F_{prime}']='matches Appendix B.2'
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true',help='also compile and check the E8 rank table over both primes');args=ap.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    report={'root_orbits':root_orbits(),'arithmetic':arithmetic()}
    print('PASS: all six root systems, coefficient orbits, projector and block arithmetic',flush=True)
    report['section5']=section5_checks()
    print('PASS: E8 rho-line relations over Z[z]; D_{2,2} centre computations over Q',flush=True)
    if args.full:
        report['e8_ranks']=e8_ranks()
        print('PASS: coefficient-five E8 rank table over F_1000003 and F_1000033',flush=True)
    report['all_checks_passed']=True
    (OUT/'math-checks.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
