#!/usr/bin/env python3
"""Exact auxiliary checks for marked semisimple uniqueness.

Checks a six-dimensional symmetric two-vertex algebra, not a proof by samples.
Also verifies a numerical ambiguity showing that Cartan data alone are insufficient.
Uses Python's standard library and rational Gaussian elimination.
"""
from fractions import Fraction
from itertools import product
import json
from pathlib import Path

# Paths of the oriented 2-cycle truncated at length three.
# e1, e2, a:1->2, b:2->1, p=ab, q=ba.
names = ('e1', 'e2', 'a', 'b', 'p', 'q')
paths = ((0, ()), (1, ()), (0, (0,)), (1, (1,)),
         (0, (0, 1)), (1, (1, 0)))
lookup = {p: i for i, p in enumerate(paths)}
start = [p[0] for p in paths]
end = [p[0] ^ (len(p[1]) % 2) for p in paths]

def mul(i, j):
    if end[i] != start[j]:
        return None
    arrows = paths[i][1] + paths[j][1]
    if len(arrows) >= 3:
        return None
    return lookup[(start[i], arrows)]

for i, j, k in product(range(6), repeat=3):
    ij, jk = mul(i, j), mul(j, k)
    left = None if ij is None else mul(ij, k)
    right = None if jk is None else mul(i, jk)
    assert left == right

radical_basis = tuple(range(2, 6))

def composable_inputs(n):
    return [xs for xs in product(radical_basis, repeat=n)
            if all(end[xs[i]] == start[xs[i+1]] for i in range(n-1))]

def cochain_basis(n):
    if n == 0:
        return [((), y) for y in range(6) if start[y] == end[y]]
    return [(xs, y) for xs in composable_inputs(n) for y in range(6)
            if start[y] == start[xs[0]] and end[y] == end[xs[-1]]]

bases = [cochain_basis(n) for n in range(4)]

def differential(n):
    source, target = bases[n], bases[n+1]
    rows = {item: i for i, item in enumerate(target)}
    matrix = [[0 for _ in source] for _ in target]
    inputs = composable_inputs(n+1)
    for col, (match, out) in enumerate(source):
        for xs in inputs:
            values = {}
            def add(y, coefficient):
                if y is not None:
                    values[y] = values.get(y, 0) + coefficient
            if n == 0:
                add(mul(xs[0], out), 1)
                add(mul(out, xs[0]), -1)
            else:
                if xs[1:] == match:
                    add(mul(xs[0], out), 1)
                for pos in range(n):
                    xy = mul(xs[pos], xs[pos+1])
                    if xy is not None and xy in radical_basis:
                        shortened = xs[:pos] + (xy,) + xs[pos+2:]
                        if shortened == match:
                            add(out, (-1) ** (pos+1))
                if xs[:-1] == match:
                    add(mul(out, xs[-1]), (-1) ** (n+1))
            for y, coefficient in values.items():
                if coefficient:
                    matrix[rows[(xs, y)]][col] += coefficient
    return matrix

def rank(matrix):
    if not matrix:
        return 0
    a = [[Fraction(x) for x in row] for row in matrix]
    pivot_row = 0
    for col in range(len(a[0])):
        row = next((i for i in range(pivot_row, len(a)) if a[i][col]), None)
        if row is None:
            continue
        a[pivot_row], a[row] = a[row], a[pivot_row]
        pivot = a[pivot_row][col]
        a[pivot_row] = [x / pivot for x in a[pivot_row]]
        for i in range(pivot_row+1, len(a)):
            if a[i][col]:
                factor = a[i][col]
                a[i] = [x - factor*y for x, y in zip(a[i], a[pivot_row])]
        pivot_row += 1
        if pivot_row == len(a):
            break
    return pivot_row

def matmul(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]

def gram(vectors):
    r = len(vectors[0])
    return [[sum(v[i]*v[j] for v in vectors) for j in range(r)] for i in range(r)]

D = [differential(n) for n in range(3)]
assert not any(x for row in matmul(D[1], D[0]) for x in row)
assert not any(x for row in matmul(D[2], D[1]) for x in row)
dims = [len(b) for b in bases]
ranks = [rank(d) for d in D]
hh = [dims[0]-ranks[0], dims[1]-ranks[1]-ranks[0], dims[2]-ranks[2]-ranks[1]]
assert dims == [4, 6, 12, 24]
assert ranks == [1, 4, 7]
assert hh == [3, 1, 1]
cartan = [[sum(start[k] == i and end[k] == j for k in range(6)) for j in range(2)] for i in range(2)]
root_vectors = [(1, 0), (0, 1), (1, 1)]
assert gram(root_vectors) == cartan
b = sum(cartan[i][i] for i in range(2))
g = sum(x*x for row in cartan for x in row) - b
relative_tangent = dims[2]-ranks[2]
semisimple_orbit = g-b+len(root_vectors)
assert relative_tangent == semisimple_orbit == 5

# Distinct marked types, identical Cartan matrix, centre dimension and unmarked type.
positive = [(2, 1)]*3 + [(0, 3), (1, 0)]
negative = [(3, 0)] + [(1, 2)]*3 + [(1, 0)]
assert sorted(positive) != sorted(negative)
assert sorted(tuple(reversed(v)) for v in positive) != sorted(negative)
assert gram(positive) == gram(negative) == [[13, 6], [6, 12]]
assert sorted(map(sum, positive)) == sorted(map(sum, negative)) == [1, 3, 3, 3, 3]

result = {
    'two_vertex_algebra': {
        'basis': names,
        'relations': 'All paths of length three vanish in the oriented two-cycle',
        'dimension': 6,
        'cartan': cartan,
        'relative_cochain_dimensions_C0_to_C3': dims,
        'differential_ranks_d0_to_d2': ranks,
        'HH0_cohomological_center_dimension': hh[0],
        'HH1_dimension': hh[1],
        'HH2_dimension': hh[2],
        'marked_change_of_basis_group_dimension': g,
        'marked_tangent_dimension': relative_tangent,
        'marked_semisimple_orbit_dimension': semisimple_orbit,
        'geometric_marked_type': root_vectors,
    },
    'numerical_ambiguity_not_a_contraction_counterexample': {
        'first_marked_type': positive,
        'second_marked_type': negative,
        'common_cartan': gram(positive),
        'common_center_dimension': 5,
        'common_unmarked_block_sizes': sorted(map(sum, positive)),
        'not_equivalent_even_after_swapping_two_labels': True,
    },
    'status': 'All assertions passed with exact rational/integer arithmetic.'
}
out = Path(__file__).resolve().parents[1] / 'build' / 'verification'
out.mkdir(parents=True, exist_ok=True)
(out / 'marked_tangent_checks.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
