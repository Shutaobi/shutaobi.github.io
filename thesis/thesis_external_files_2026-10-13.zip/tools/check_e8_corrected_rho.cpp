// Coefficient-five E8 cocenter rank calculation with the rho-line signs
// derived from the preprojective relations (rather than the inconsistent T symbols).
// Coefficients are exact in F_1000003; no external algebra packages are used.
// Compile: c++ -O3 -std=c++17 check_e8_corrected_rho.cpp -o check_e8
// Run: ./check_e8 23
// 'b' has weight 1, 'g' has weight 2, and the central variable z has weight 1.
// A column is z^(degree-weight(word))*[word]_cyclic.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
static constexpr int MOD=1000003;
int power(int a, int b) { int r=1; for(;b;b>>=1,a=int(int64_t(a)*a%MOD)) if(b&1)r=int(int64_t(r)*a%MOD); return r; }
string cyclic(const string& s) {
    string r=s;
    for(size_t i=1;i<s.size();++i) { string t=s.substr(i)+s.substr(0,i); if(t<r)r=move(t); }
    return r;
}
struct Term { int coef; int z; string w; };
struct Rel { int degree; vector<Term> t; };
void words(int remaining, string& s, vector<string>& out) {
    out.push_back(s);
    if(remaining>=1) {s+='b';words(remaining-1,s,out);s.pop_back();}
    if(remaining>=2) {s+='g';words(remaining-2,s,out);s.pop_back();}
}
int weight(const string& s){int n=0;for(char c:s)n+=(c=='b'?1:2);return n;}
int main(int argc,char**argv) {
    int maxdeg=argc>1?atoi(argv[1]):23;
    if(maxdeg<0||maxdeg>28){cerr<<"Degree must be in [0,28].\n";return 2;}
    vector<Rel> rels={
      {4,{{1,0,"bbbb"},{-22,1,"bbb"},{179,2,"bb"},{-638,3,"b"},{840,4,""}}},
      {4,{{1,0,"gg"},{1,0,"gbb"},{1,0,"bbg"},{1,0,"bbbb"},{1,0,"bgb"},{-5,2,"g"},{-5,2,"bb"},{4,4,""}}},
      {5,{{1,0,"gbg"},{1,0,"ggb"},{1,0,"gbbb"},{-5,2,"gb"}}}
    };
    for(auto&r:rels)for(auto&t:r.t)assert(t.z+weight(t.w)==r.degree);
    int total=0; int mindeg=argc>2?atoi(argv[2]):0;
    cout<<"field=F_1000003\ndegree columns rank nullity rows\n";
    for(int m=mindeg;m<=maxdeg;++m) {
        vector<string> all;string s;words(m,s,all);
        unordered_map<string,string> canon;canon.reserve(all.size()*2);
        vector<string> columns;
        for(const auto&w:all) {string c=cyclic(w);canon.emplace(w,c);if(c==w)columns.push_back(c);}
        sort(columns.begin(),columns.end(),[](const string&a,const string&b){
            int aw=weight(a),bw=weight(b);return aw==bw?a<b:aw<bw;
        });
        columns.erase(unique(columns.begin(),columns.end()),columns.end());
        unordered_map<string,int> index;index.reserve(columns.size()*2);
        for(int i=0;i<(int)columns.size();++i)index.emplace(columns[i],i);
        int n=columns.size(), rank=0,nrows=0;
        vector<vector<pair<int,int>>> piv(n);
        vector<int> row(n);
        for(const auto&r:rels) {
            if(r.degree>m)continue;
            vector<string> multiples;words(m-r.degree,s,multiples);
            for(const auto&w:multiples) {
                ++nrows;fill(row.begin(),row.end(),0);
                // The central exponent of the multiplier is m-r.degree-weight(w).
                for(const auto&t:r.t) {
                    const string joined=t.w+w;
                    int j=index.at(canon.at(joined));
                    int v=row[j]+t.coef;v%=MOD;if(v<0)v+=MOD;row[j]=v;
                }
                for(int j=0;j<n;++j) {
                    if(row[j]==0)continue;
                    if(piv[j].empty()) {
                        int inv=power(row[j],MOD-2);
                        for(int k=j;k<n;++k)if(row[k])piv[j].emplace_back(k,int(int64_t(row[k])*inv%MOD));
                        ++rank;break;
                    }
                    const int c=row[j];
                    for(auto [k,v]:piv[j]) {
                        int t=int(int64_t(c)*v%MOD);
                        int x=row[k]-t;if(x<0)x+=MOD;row[k]=x;
                    }
                }
            }
        }
        int h=n-rank;total+=h;
        cout<<m<<" "<<n<<" "<<rank<<" "<<h<<" "<<nrows<<endl;
    }
    cout<<"sum_nullities="<<total<<endl;
}
