#!/usr/bin/env python3
"""Exact checks of the D_{2,2} centre tangent image (thesis, Section 5.6).

Python 3.10+; standard library only. All arithmetic is over Q (Fraction).
Run from any directory: python3 tools/check_d22_tangent_image.py

Uses the matrix builders of verify_conjecture_1_4_counterexample.py and checks:
  (1) the centre tangent map chi_A: HH^2(A) -> T^1_com(Z(A)) has rank 3;
  (2) psi_1, psi_2, psi_3 of Proposition 5.18(iii) are symmetric normalized
      cocycles whose classes span the image of chi_A;
  (3) after reduction modulo commutative coboundaries, their coordinates
      (w in psi(u,v)), (w in psi(u,w)), (q in psi(u,q)) form a matrix of
      determinant -1;
  (4) the socle condition psi(s,s) in Cs + m^2 for all s in Soc(Z(A))
      holds for all 53 image cocycles and the 20 coboundary generators,
      as a polynomial identity in the coordinates of s;
  (5) psi_0 with psi_0(v,v) = w violates the socle condition.
Centre basis: 0=1, 1=u=x^2, 2=v=x^3, 3=w=x^2y, 4=q=x^4.
"""
import sys
from fractions import Fraction as F
from itertools import product

sys.dont_write_bytecode = True  # keep tools/ free of __pycache__
import verify_conjecture_1_4_counterexample as V  # noqa: E402

A, _ = V.algebra_D_n2(2)
C = V.centre_table()
ar, ac = V.differential_two(A, 8)
cr, cc = V.differential_two(C, 5, symmetric=True)
cb = V.coboundaries(C, 5, cc)
cocycles_A = V.nullspace(V.echelon(ar), len(ac))
images = [V.induced_centre_cocycle(phi, A, C, ac, cc) for phi in cocycles_A]
rank_cb = V.rank(cb)
assert len(cocycles_A) == 53
assert V.rank(cb + images) - rank_cb == 3            # (1)

INDEX = {'u': 1, 'v': 2, 'w': 3, 'q': 4}


def cocycle(entries):
    vector = {}
    for (a, b, k), value in entries.items():
        i, j = sorted((INDEX[a], INDEX[b]))
        vector[cc[i, j, INDEX[k]]] = F(value)
    return vector


PSI = [
    cocycle({('u', 'w', 'w'): -1, ('u', 'q', 'q'): -2, ('v', 'v', 'q'): 1}),
    cocycle({('u', 'v', 'w'): F(-1, 2), ('u', 'w', 'v'): F(1, 2),
             ('v', 'w', 'q'): F(1, 2)}),
    cocycle({('u', 'w', 'w'): -2, ('u', 'q', 'q'): -2, ('w', 'w', 'q'): 2}),
]
for psi in PSI:                                       # (2)
    assert all(V.pairing(row, psi) == 0 for row in cr)
assert V.rank(cb + images + PSI) == V.rank(cb + images)
assert V.rank(cb + PSI) - rank_cb == 3

pivots = V.echelon(cb)                                # (3)
coordinates = [cc[1, 2, 3], cc[1, 3, 3], cc[1, 4, 4]]
assert not any(c in pivots for c in coordinates)


def reduce(vector):
    row = {i: F(v) for i, v in vector.items() if v}
    for j in sorted(pivots):
        if j in row:
            factor = row[j]
            for i, value in pivots[j].items():
                V.add_term(row, i, -factor * value)
    return row


M = [[reduce(psi).get(c, F(0)) for c in coordinates] for psi in PSI]
det = (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
       - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
       + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))
assert det == -1

# (4) polynomials in the coordinates (alpha, beta, gamma) of
# s = alpha v + beta w + gamma q, as dicts {exponent triple: Fraction}.
MONOMIAL = {2: (1, 0, 0), 3: (0, 1, 0), 4: (0, 0, 1)}


def padd(poly, monomial, value):
    if value:
        poly[monomial] = poly.get(monomial, F(0)) + value
        if poly[monomial] == 0:
            del poly[monomial]


def pmul(p, q):
    out = {}
    for m1, c1 in p.items():
        for m2, c2 in q.items():
            padd(out, tuple(a + b for a, b in zip(m1, m2)), c1 * c2)
    return out


def psi_on_socle_diagonal(vector):
    out = {k: {} for k in range(5)}
    for i, j in product(MONOMIAL, repeat=2):
        a, b = sorted((i, j))
        monomial = tuple(x + y for x, y in zip(MONOMIAL[i], MONOMIAL[j]))
        for k in range(5):
            padd(out[k], monomial, F(vector.get(cc[a, b, k], 0)))
    return out


def socle_condition(vector):
    """psi(s,s) in Cs + m^2 with m^2 = Cq, for all s in Soc."""
    o = psi_on_socle_diagonal(vector)
    parallel = pmul(o[2], {(0, 1, 0): F(1)})          # v-part * beta
    for monomial, value in pmul(o[3], {(1, 0, 0): F(1)}).items():
        padd(parallel, monomial, -value)              # - w-part * alpha
    return not o[0] and not o[1] and not parallel


assert all(socle_condition(v) for v in images)
assert all(socle_condition(v) for v in cb)
assert all(socle_condition(v) for v in PSI)
WITNESS = {cc[2, 2, 3]: 1}                            # (5) psi_0(v,v) = w
assert all(V.pairing(row, WITNESS) == 0 for row in cr)
assert not socle_condition(WITNESS)

print('Exact verification over Q (Python fractions.Fraction)')
print('D_{2,2}: rank of the centre tangent map = 3: PASS')
print('psi_1, psi_2, psi_3 are cocycles spanning the image: PASS')
print('Minor after reduction modulo coboundaries:',
      [[str(x) for x in row] for row in M], 'det =', det)
print('Socle condition on 53 image cocycles and 20 coboundaries: PASS')
print('psi_0(v,v) = w violates the socle condition: PASS')
print('ALL CHECKS PASSED')
