Thesis Computational Tools

This package contains six source files in tools/ and a Makefile.
No LaTeX source, typesetting configuration, audit reports, or saved run output is included.

Requirements
  Python 3.10 or newer (standard library only)
  A C++17 compiler named c++ for the full E8 rank calculation
  make, or use the Python commands below directly

Full calculation
  make math

Python-only calculations
  make quick

Without make
  python3 tools/check_mathematics.py --full
  python3 tools/check_marked_tangent.py

Source files
  tools/check_mathematics.py
    Runs the root-system, arithmetic, E8, and D22 calculations.
  tools/check_marked_tangent.py
    Checks the marked tangent examples using exact rational arithmetic.
  tools/check_e8_corrected_rho.cpp
    Computes the corrected E8 relation ranks over finite fields.
  tools/check_e8_rho_relations_formal.py
    Checks the E8 relations over Z[z].
  tools/verify_conjecture_1_4_counterexample.py
    Checks the D22 cochain and centre calculations over Q.
  tools/check_d22_tangent_image.py
    Checks the D22 centre tangent image and socle condition over Q.

Output
  Running the programs creates build/verification/ for generated results and logs.
  These files are output, not required input, and are omitted from this package.
