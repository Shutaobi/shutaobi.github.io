# On the Type E case of the Brown--Wemyss realization conjecture

Shutao Bi. November 12, 2026 revision.

## Compile the manuscript

`Geometric_Realization.tex` is the main document. Its bibliography is included
in the same file. With pdfLaTeX and latexmk available, run this command from
the extracted archive directory.

```sh
latexmk -norc -pdf -interaction=nonstopmode -halt-on-error Geometric_Realization.tex
```

The output is `Geometric_Realization.pdf`. The current layout uses A4 paper,
a 10pt Latin Modern text font, standard single spacing, and 20mm margins.
The main TeX file is at the archive root for source submission.

## Reproduce the exact computations

The three programs and both JSON files are in
`tools/numerical_realisation_certificates/`, following Section 6 of the paper.
The commands below start in the extracted archive directory.
Use Python 3.10 or later with assertions enabled.

```sh
python3 tools/numerical_realisation_certificates/verify_cyclic_reductions.py
python3 tools/numerical_realisation_certificates/verify_zero_quartic.py
```

For the length-five calculation, install the pinned dependencies in a virtual
environment and write the newly computed certificate into `build/`.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-certificates.txt
python tools/numerical_realisation_certificates/nr_B5_generic_certificate.py --output build/nr_B5_rerun.json
cmp build/nr_B5_rerun.json tools/numerical_realisation_certificates/nr_B5_generic_certificate.json
```

On Windows, activate the environment with `.venv\Scripts\activate` and use
`fc.exe /b` to compare the JSON files. A matching file gives exit status zero.

## Connection to the proof

- `verify_cyclic_reductions.py` checks the length-three overlaps in Lemma 2.13
  and the finite algebra and cocenter calculations in Theorem 2.16.
- `verify_zero_quartic.py` reads `zero_quartic_certificate.json` to verify the
  rational identities and Hilbert series used in Lemma 4.4.
- `nr_B5_generic_certificate.py` recomputes the specializations in Lemma 3.4.
  `nr_B5_generic_certificate.json` supplies the reference output for comparison.

The first two programs use the Python standard library. The length-five
program uses SymPy 1.14.0 and mpmath 1.3.0, pinned in the requirements file.
The manuscript supplies the formal lifting and geometric arguments that use
these finite calculations.
